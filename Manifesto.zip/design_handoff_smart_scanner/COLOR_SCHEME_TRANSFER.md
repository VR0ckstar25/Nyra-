# Anvara — Color Scheme Transfer File

Complete color system for the Anvara (Smart Food Ingredients Scanner) app.
**3 brand directions × 3 modes (Light / Dim / Black), plus a fixed safety palette.**
Machine-readable tokens + resolver live in **`anvara-theme-tokens.js`** (use `buildTheme(direction, mode)`).

---

## How it's organized
- **Direction** = brand personality (type + accent family). User-selectable.
- **Mode** = `light` (bright default), `dim` (tuned dark), `black` (pure-OLED, bolder glowing accents). User-selectable.
- **Safety palette** = the amber finding-dot + category colors. **Fixed** — resolves per mode for contrast, but is never re-skinned per brand and never red/green.

Any direction × any mode is valid (3 × 3 = 9 full themes).

---

## Roles (what each token paints)
`bg` page · `surface` cards · `panel` wells/chips · `ink/ink2/ink3` text 1–3 · `line/lineSoft` borders · `accent` CTAs & selection · `accentDeep` pressed/`onAccent`-on-soft text · `accentSoft` tinted fills · `onAccent` text on accent (always white) · `stage` area behind the phone · `glow` primary-button shadow (Black mode only).

---

## ★ Clear & Kind — indigo · Plus Jakarta Sans (default, recommended)
| Token | Light | Dim | Black (OLED) |
|---|---|---|---|
| bg | `#FFFFFF` | `#0E121A` | `#000000` |
| surface | `#FFFFFF` | `#161B24` | `#0A0C10` |
| panel | `#F3F6FA` | `#1A1F29` | `#101216` |
| ink | `#14181F` | `#EEF1F6` | `#F4F7FC` |
| ink2 | `#535B68` | `#A6AEBC` | `#A8B0BE` |
| ink3 | `#9099A6` | `#6B7383` | `#646B79` |
| line | `#E6EBF1` | `#262C38` | `#1E222B` |
| accent | `#3A5BDC` | `#4F6BEA` | `#3D6BFF` |
| accentDeep | `#2B45B0` | `#AEC0FF` | `#9FB8FF` |
| accentSoft | `#E8ECFC` | `rgba(79,107,234,.20)` | `rgba(61,107,255,.18)` |
| onAccent | `#FFFFFF` | `#FFFFFF` | `#FFFFFF` |
| stage | `#E9ECF2` | `#10141C` | `#000000` |

Black glow: `0 0 0 1px rgba(61,107,255,.4), 0 8px 26px rgba(61,107,255,.5)`

## Bright & Bold — violet · Space Grotesk
| Token | Light | Dim | Black (OLED) |
|---|---|---|---|
| bg | `#FFFFFF` | `#120E1F` | `#000000` |
| surface | `#FFFFFF` | `#1A1428` | `#0C0814` |
| panel | `#F6F4FC` | `#1F1830` | `#140E22` |
| ink | `#191427` | `#F1EEF8` | `#F4F0FC` |
| ink2 | `#574F69` | `#ABA2BD` | `#ADA3C0` |
| ink3 | `#938CA6` | `#726A85` | `#6A6080` |
| line | `#ECE7F4` | `#2C2440` | `#241B36` |
| accent | `#7C3AED` | `#8B52F5` | `#9A4DFF` |
| accentDeep | `#5E27C0` | `#C9B3FB` | `#D4B8FF` |
| accentSoft | `#EFE7FD` | `rgba(139,82,245,.22)` | `rgba(154,77,255,.20)` |
| stage | `#EDE9F6` | `#150F22` | `#000000` |

Black glow: `0 0 0 1px rgba(154,77,255,.45), 0 8px 28px rgba(154,77,255,.55)`

## Warm & Soft — magenta · Newsreader (serif headlines)
| Token | Light | Dim | Black (OLED) |
|---|---|---|---|
| bg | `#FCFBF9` | `#1A1416` | `#000000` |
| surface | `#FFFFFF` | `#211A1C` | `#0E090A` |
| panel | `#F4F0EA` | `#261E20` | `#181012` |
| ink | `#23201C` | `#F4EEEA` | `#F8EFEC` |
| ink2 | `#615B53` | `#B6AAA2` | `#BCADA6` |
| ink3 | `#A39A8E` | `#7C7069` | `#776A66` |
| line | `#ECE6DC` | `#332A2C` | `#2A1E22` |
| accent | `#B23A8E` | `#CE4DA3` | `#FF3D9C` |
| accentDeep | `#8C2C6F` | `#F0AED6` | `#FFACD7` |
| accentSoft | `#F7E3F0` | `rgba(206,77,163,.20)` | `rgba(255,61,156,.18)` |
| stage | `#EFEAE3` | `#1B1517` | `#000000` |

Black glow: `0 0 0 1px rgba(255,61,156,.42), 0 8px 28px rgba(255,61,156,.52)`

---

## 🔒 Fixed safety palette (resolves by mode, never by brand)
`rail` = category line/dot · `chipBg` = badge background · `fg` = text on chip & on surface.

| Token | Light | Dim | Black |
|---|---|---|---|
| **amber dot** (finding present) | `#E89318` | `#F0A23A` | `#FFB23D` |
| allergen · rail | `#D2870F` | `#E0A030` | `#FFB23D` |
| allergen · chipBg | `#FDEBC9` | `rgba(224,160,48,.18)` | `rgba(255,178,61,.16)` |
| allergen · fg | `#96640F` | `#F0C079` | `#FFCE85` |
| intolerance · rail | `#CA6A2C` | `#DE8048` | `#FF9352` |
| intolerance · chipBg | `#FBE2CC` | `rgba(222,128,72,.18)` | `rgba(255,147,82,.16)` |
| intolerance · fg | `#A1531F` | `#EDA777` | `#FFB68A` |
| goal · rail | `#6A7396` | `#8C97B8` | `#A6B2D6` |
| goal · fg | `#4D5772` | `#B6C0D6` | `#C7D0E8` |
| could-not-verify text | `#8E857A` | `#9AA1AD` | `#8A93A2` |

Child-profile avatar (all modes): bg `#E7D9C4`, fg `#8A6B3D`.

### Rules (do not break)
- No red, no green, anywhere. No score / grade / safe-vs-unsafe verdict.
- Finding = amber dot **+** category rail **+** "Contains/May contain" text. Color is never the only signal (colorblind-safe).
- Accent buttons always use **white** text (`onAccent`) — AA+ in every mode.
- In **Black** mode the primary button carries its `glow` shadow; raised cards stay near-black (`surface`), not pure black, so depth reads.

---

## Type
| Use | Family | Notes |
|---|---|---|
| Display / headlines | per direction: Plus Jakarta Sans 800 · Space Grotesk 700 · Newsreader 600 | tracking per direction |
| Body / UI | Plus Jakarta Sans 400–800 | common name always larger than technical name |
| Mono | Spline Sans Mono | dates, overlines, "Contains/May contain" labels, placeholders |

---

## Promotion / paywall colors
The Plus promo screen reuses theme tokens only:
- Hero band = `accent` with `onAccent` text (Black mode adds an accent drop-glow).
- Plan cards = `surface`; selected card = 2px `accent` ring (+ glow in Black). "Most popular" badge = `accent`/`onAccent`.
- Billing toggle, feature checks, CTA = `accentSoft` / `accentDeep` / `accent` as elsewhere.
**Two tiers:** Individual (1 profile) and Family (up to 6 profiles + Child Mode + shared sessions).

---

## Usage
```js
import { buildTheme, applyTheme } from './anvara-theme-tokens.js';

const t = buildTheme('clear', 'black');   // → flat theme object
applyTheme(document.documentElement, 'clear', 'black'); // → CSS vars (--bg, --accent, …, --btn-glow)
```
Persist the user's two choices (e.g. `{ direction:'clear', mode:'black' }`) and re-apply on launch. Map all component colors to these tokens; keep the safety palette as constants routed only through `buildTheme`, never through the user picker.
