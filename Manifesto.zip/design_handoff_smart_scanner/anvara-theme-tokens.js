// anvara-theme-tokens.js
// ─────────────────────────────────────────────────────────────────────────────
// ANVARA — COMPLETE COLOR SCHEME (transfer file)
// Smart Food Ingredients Scanner.
//
// Structure: 3 brand DIRECTIONS × 3 MODES (light / dim / black) + one FIXED
// safety palette that resolves per mode. Resolve a final theme with
// buildTheme(direction, mode); apply the returned object's values to CSS vars
// or a native theme context.
//
// MODES
//   light  — bright white/near-white base (default for daytime, mass appeal)
//   dim    — tuned dark, each direction keeps its hue on a near-black base
//   black  — pure-black OLED canvas + BOLDER, electric accents that glow
//
// SAFETY RULES (non-negotiable — do NOT theme these away):
//   • amber filled dot = "finding present", on every match bar
//   • category shown by RAIL color + label, never by red/green
//   • wording carries risk: "Contains" vs "May contain"
//   • findings never rely on color alone (always paired with text)
//   • accents always take WHITE button text (onAccent) at AA+
// ─────────────────────────────────────────────────────────────────────────────

// ── 3 brand directions, LIGHT (the base) ──
export const DIRECTIONS = {
  clear: {
    label: 'Clear & Kind',                 // confident indigo, max legibility
    head: "'Plus Jakarta Sans', sans-serif", body: "'Plus Jakarta Sans', sans-serif",
    headWeight: 800, headTracking: '-0.4px', radius: 16, buttonRadius: 999,
    light: { bg:'#FFFFFF', panel:'#F3F6FA', surface:'#FFFFFF', ink:'#14181F', ink2:'#535B68', ink3:'#9099A6',
             line:'#E6EBF1', lineSoft:'#F1F4F8', accent:'#3A5BDC', accentDeep:'#2B45B0', accentSoft:'#E8ECFC', onAccent:'#FFFFFF', stage:'#E9ECF2' },
  },
  bold: {
    label: 'Bright & Bold',                // electric violet, geometric type
    head: "'Space Grotesk', sans-serif", body: "'Plus Jakarta Sans', sans-serif",
    headWeight: 700, headTracking: '-0.6px', radius: 22, buttonRadius: 16,
    light: { bg:'#FFFFFF', panel:'#F6F4FC', surface:'#FFFFFF', ink:'#191427', ink2:'#574F69', ink3:'#938CA6',
             line:'#ECE7F4', lineSoft:'#F5F2FA', accent:'#7C3AED', accentDeep:'#5E27C0', accentSoft:'#EFE7FD', onAccent:'#FFFFFF', stage:'#EDE9F6' },
  },
  warm: {
    label: 'Warm & Soft',                  // friendly magenta, serif headlines
    head: "'Newsreader', serif", body: "'Plus Jakarta Sans', sans-serif",
    headWeight: 600, headTracking: '-0.2px', radius: 18, buttonRadius: 14,
    light: { bg:'#FCFBF9', panel:'#F4F0EA', surface:'#FFFFFF', ink:'#23201C', ink2:'#615B53', ink3:'#A39A8E',
             line:'#ECE6DC', lineSoft:'#F4EFE7', accent:'#B23A8E', accentDeep:'#8C2C6F', accentSoft:'#F7E3F0', onAccent:'#FFFFFF', stage:'#EFEAE3' },
  },
};

// ── DIM mode overlays (per direction) ──
export const DIM = {
  clear: { bg:'#0E121A', panel:'#1A1F29', surface:'#161B24', ink:'#EEF1F6', ink2:'#A6AEBC', ink3:'#6B7383', line:'#262C38', lineSoft:'#1E2430', accent:'#4F6BEA', accentDeep:'#AEC0FF', accentSoft:'rgba(79,107,234,.20)', onAccent:'#FFFFFF', stage:'#10141C' },
  bold:  { bg:'#120E1F', panel:'#1F1830', surface:'#1A1428', ink:'#F1EEF8', ink2:'#ABA2BD', ink3:'#726A85', line:'#2C2440', lineSoft:'#231C34', accent:'#8B52F5', accentDeep:'#C9B3FB', accentSoft:'rgba(139,82,245,.22)', onAccent:'#FFFFFF', stage:'#150F22' },
  warm:  { bg:'#1A1416', panel:'#261E20', surface:'#211A1C', ink:'#F4EEEA', ink2:'#B6AAA2', ink3:'#7C7069', line:'#332A2C', lineSoft:'#281F22', accent:'#CE4DA3', accentDeep:'#F0AED6', accentSoft:'rgba(206,77,163,.20)', onAccent:'#FFFFFF', stage:'#1B1517' },
};

// ── BLACK (OLED) mode overlays — pure-black bg + bolder, glowing accents ──
// `glow` is the box-shadow for primary buttons in this mode.
export const BLACK = {
  clear: { bg:'#000000', panel:'#101216', surface:'#0A0C10', ink:'#F4F7FC', ink2:'#A8B0BE', ink3:'#646B79', line:'#1E222B', lineSoft:'#151920', accent:'#3D6BFF', accentDeep:'#9FB8FF', accentSoft:'rgba(61,107,255,.18)', onAccent:'#FFFFFF', stage:'#000000', glow:'0 0 0 1px rgba(61,107,255,.4), 0 8px 26px rgba(61,107,255,.5)' },
  bold:  { bg:'#000000', panel:'#140E22', surface:'#0C0814', ink:'#F4F0FC', ink2:'#ADA3C0', ink3:'#6A6080', line:'#241B36', lineSoft:'#181023', accent:'#9A4DFF', accentDeep:'#D4B8FF', accentSoft:'rgba(154,77,255,.20)', onAccent:'#FFFFFF', stage:'#000000', glow:'0 0 0 1px rgba(154,77,255,.45), 0 8px 28px rgba(154,77,255,.55)' },
  warm:  { bg:'#000000', panel:'#181012', surface:'#0E090A', ink:'#F8EFEC', ink2:'#BCADA6', ink3:'#776A66', line:'#2A1E22', lineSoft:'#1A1214', accent:'#FF3D9C', accentDeep:'#FFACD7', accentSoft:'rgba(255,61,156,.18)', onAccent:'#FFFFFF', stage:'#000000', glow:'0 0 0 1px rgba(255,61,156,.42), 0 8px 28px rgba(255,61,156,.52)' },
};

// ── FIXED safety palette, resolved per mode (NOT brand-themeable) ──
// rail = category accent line/dot; chipBg = badge background; fg = text on chip & on surface.
export const SAFETY = {
  light: {
    amber:'#E89318', unknownInk:'#8E857A',
    allergen:    { rail:'#D2870F', chipBg:'#FDEBC9', fg:'#96640F' },
    intolerance: { rail:'#CA6A2C', chipBg:'#FBE2CC', fg:'#A1531F' },
    goal:        { rail:'#6A7396', chipBg:'#E7E9F1', fg:'#4D5772' },
  },
  dim: {
    amber:'#F0A23A', unknownInk:'#9AA1AD',
    allergen:    { rail:'#E0A030', chipBg:'rgba(224,160,48,.18)', fg:'#F0C079' },
    intolerance: { rail:'#DE8048', chipBg:'rgba(222,128,72,.18)', fg:'#EDA777' },
    goal:        { rail:'#8C97B8', chipBg:'rgba(140,151,184,.20)', fg:'#B6C0D6' },
  },
  black: {
    amber:'#FFB23D', unknownInk:'#8A93A2',
    allergen:    { rail:'#FFB23D', chipBg:'rgba(255,178,61,.16)', fg:'#FFCE85' },
    intolerance: { rail:'#FF9352', chipBg:'rgba(255,147,82,.16)', fg:'#FFB68A' },
    goal:        { rail:'#A6B2D6', chipBg:'rgba(166,178,214,.18)', fg:'#C7D0E8' },
  },
};

// child-profile avatar colors are constant across modes
export const CHILD = { bg:'#E7D9C4', fg:'#8A6B3D' };

export const FONT_STACKS = {
  display: { clear: "'Plus Jakarta Sans'", bold: "'Space Grotesk'", warm: "'Newsreader'" },
  body: "'Plus Jakarta Sans'",
  mono: "'Spline Sans Mono'", // dates, placeholders, overlines
};

// ── Resolver: one flat theme object for a (direction, mode) pair ──
export function buildTheme(direction = 'clear', mode = 'light') {
  const d = DIRECTIONS[direction] || DIRECTIONS.clear;
  const overlay = mode === 'black' ? BLACK[direction] : mode === 'dim' ? DIM[direction] : d.light;
  const safety = SAFETY[mode] || SAFETY.light;
  return {
    direction, mode,
    head: d.head, body: d.body, headWeight: d.headWeight, headTracking: d.headTracking,
    radius: d.radius, buttonRadius: d.buttonRadius,
    ...d.light, ...overlay,           // overlay wins for dim/black
    ...safety, child: CHILD,
    isDark: mode !== 'light', isBlack: mode === 'black',
  };
}

// ── Optional: write a resolved theme onto a root element as CSS variables ──
export function applyTheme(el, direction, mode) {
  const t = buildTheme(direction, mode);
  const vars = ['bg','panel','surface','ink','ink2','ink3','line','lineSoft','accent','accentDeep','accentSoft','onAccent','stage'];
  vars.forEach((k) => el.style.setProperty(`--${k}`, t[k]));
  el.style.setProperty('--amber', t.amber);
  if (t.glow) el.style.setProperty('--btn-glow', t.glow);
}
