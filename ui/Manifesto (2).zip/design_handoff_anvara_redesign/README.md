# Handoff: Anvara — Redesign (themeable allergen-label scanner)

## Overview
Anvara is a mobile app that reads packaged-food labels with the camera and checks the
ingredients against each family member's declared allergies, intolerances, and dietary
goals. It never gives a verdict ("safe"/"unsafe") — it surfaces **findings** the user
decides on. This redesign delivers one product across **three independent theming axes**:

- **Direction** — `precision` · `signal` · `hearth` (typography, shape language, layout rhythm, neutral palette)
- **Accent colour** — `cobalt` · `indigo` · `plum` · `turquoise` · `fuchsia` · `grape` (CTA / selection colour only)
- **Mode** — `light` · `dim` · `black` (surface luminance; `black` is true-OLED #000)

Any Direction × Accent × Mode combination is valid (3 × 6 × 3 = 54 themes). An in-app
**Appearance** screen (Profile → Appearance) lets the end user pick all three live.

## About the Design Files
The files in this bundle are **design references created in HTML/React (Babel-in-browser)** —
prototypes showing intended look and behaviour, **not production code to ship directly**.
The task is to **recreate these designs in the target codebase's environment** (React Native,
SwiftUI, Flutter, etc.) using its established patterns, navigation, and component libraries.
If no environment exists yet, choose the most appropriate framework and implement there.

The prototype is structured exactly the way production should be: a single theme resolver
(`buildS(direction, accent, mode)`) returns a flat token object `S`, and every screen reads
only from `S`. Port that resolver first; the screens follow naturally.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, radii, shadows, icons, copy, and
interactions are all specified. Recreate pixel-faithfully, but **map the theme tokens onto
the target platform's theming system** rather than hard-coding values per screen.

---

## The theme system (build this first)

`buildS(dirKey, accentKey, mode)` merges three token sources into one object `S`:

1. **Direction base** (structure + neutrals) — see DIRECTIONS table
2. **Mode overlay** (only when `dim`/`black`) — replaces bg/surface/ink/line neutrals
3. **Accent triplet** for the active mode — `{ a, d, s }` → `S.accent / S.accentDeep / S.accentSoft`
4. **Fixed safety palette** for the active mode — never affected by accent (see SAFETY)

Resolved keys every component uses:
`bg, panel, surface, dark, ink, ink2, ink3, line, lineSoft` (neutrals) ·
`accent, accentDeep, accentSoft, onAccent, glow` (accent) ·
`head, body, mono, headWt, headLs, radius, btnR, card, shadow, shadowSoft, stage` (direction) ·
`amber, unknownInk, allergen{rail,chipBg,fg}, intolerance{…}, goal{…}` (safety) ·
`dir, accentKey, mode, isDark, isBlack, childBg, childFg` (meta).

`onAccent` is always `#FFFFFF`. `glow` is set only in `black` mode
(`0 0 0 1px {a}66, 0 8px 28px {a}99`) and used as the primary-button / accent-surface shadow
so CTAs bloom on pure black; in light/dim it's null and a soft `{accent}30` shadow is used.

### DIRECTIONS (structure + LIGHT-mode neutrals)
| token | precision | signal | hearth |
|---|---|---|---|
| head font | IBM Plex Sans | Space Grotesk | Source Serif 4 |
| body font | Hanken Grotesk (all three) | — | — |
| mono font | IBM Plex Mono | Spline Sans Mono | Spline Sans Mono |
| headWt | 600 | 700 | 600 |
| headLs (letter-spacing) | -0.3px | -1px | -0.2px |
| radius (cards) | 12 | 22 | 18 |
| btnR (buttons) | 10 | 16 | 13 |
| card style | `border` (1px inset line) | `shadow` (elevated) | `soft` (low shadow) |
| bg | #F5F8FA | #FFFFFF | #FAF6F0 |
| panel | #E9F0F5 | #F0F1F8 | #F0E8DD |
| surface | #FFFFFF | #FFFFFF | #FFFFFF |
| dark (viewfinder) | #0B1117 | #0A0B14 | #1E1712 |
| ink | #0E1822 | #0B0D16 | #241E18 |
| ink2 | #4C5A66 | #525870 | #5E564C |
| ink3 | #8896A2 | #9095AC | #9C9183 |
| line | #E0E8EE | #E7E8F1 | #EAE2D5 |
| lineSoft | #EEF3F7 | #F2F2F8 | #F3ECE1 |
| stage (letterbox) | #DCE4EB | #ECECF4 | #ECE4D8 |

`card` semantics — `border`: `inset 0 0 0 1px line`, no shadow · `soft`: `shadowSoft` ·
`shadow`: full `shadow`. All three use `surface` bg and `radius`.

### DIM mode neutral overlay (replaces the rows above when mode==='dim')
| token | precision | signal | hearth |
|---|---|---|---|
| bg | #0B1018 | #0C0D17 | #181210 |
| panel | #161D27 | #191A28 | #241C18 |
| surface | #121925 | #14151F | #1F1814 |
| ink | #EAF0F6 | #EEEEF8 | #F4ECE3 |
| ink2 | #A2AEBC | #A6A8C0 | #B7A99C |
| ink3 | #65717F | #6C6E86 | #7E7064 |
| line | #222B38 | #262640 | #322821 |
| lineSoft | #1A222E | #1C1C2E | #261E19 |
| stage | #0C121A | #101120 | #1A130F |

### BLACK (OLED) mode neutral overlay
bg/dark/stage are all `#000000`. Others:
| token | precision | signal | hearth |
|---|---|---|---|
| panel | #0E1319 | #100F1C | #150F12 |
| surface | #080B10 | #0A0912 | #0C0809 |
| ink | #F1F6FB | #F1F0FC | #F7EFE9 |
| ink2 | #A4AFBD | #ABA9C2 | #BCAEA3 |
| ink3 | #5F6975 | #67657F | #776A63 |
| line | #1B2129 | #201E32 | #271D20 |
| lineSoft | #12161D | #15131F | #170F12 |

### ACCENTS (triplet per mode: a = accent, d = deep, s = soft fill)
Excludes red & green by product rule (those read as verdicts). `swatch` is the picker dot.
| accent | swatch | light a / d / s | dim a / d / s | black a / d / s |
|---|---|---|---|---|
| cobalt | #1B4FA0 | #1B4FA0 / #143C7D / #DEE9F6 | #3E73D8 / #A9C2EF / rgba(62,115,216,.20) | #3F78FF / #A8C2FF / rgba(63,120,255,.18) |
| indigo | #4733FF | #4733FF / #3422DB / #E6E2FF | #7E6BFF / #C7BCFF / rgba(126,107,255,.22) | #7A66FF / #CFC4FF / rgba(122,102,255,.20) |
| plum | #7E3A6E | #7E3A6E / #632C58 / #F1E4EE | #C66FAC / #EEBADD / rgba(198,111,172,.20) | #E96FBE / #FFB6E1 / rgba(233,111,190,.18) |
| turquoise | #0E8F8C | #0E8F8C / #0B6F6D / #D5EFEE | #3FB8B5 / #A9E8E6 / rgba(63,184,181,.20) | #2BD4CF / #9DEFEC / rgba(43,212,207,.16) |
| fuchsia | #D6398A | #D6398A / #AC2C6E / #FAE0EE | #E86BAA / #F6B9D7 / rgba(232,107,170,.20) | #FF4D9E / #FFB0D6 / rgba(255,77,158,.16) |
| grape | #8139C2 | #8139C2 / #66299E / #EFE0F8 | #A86BE0 / #D9BCF5 / rgba(168,107,224,.20) | #B14DFF / #DDB8FF / rgba(177,77,255,.18) |

Defaults: `precision` / `cobalt` / `light`.

---

## SAFETY SYSTEM (fixed — must never be themed)
This is the product's core trust contract. Do not let accent or direction touch it.
- **Amber dot** = "a finding is present here." Same amber everywhere.
- **Category is shown by a rail/tint colour AND an always-present text label** (colour is never the sole signal — colourblind-safe).
- Wording is **"Contains"** (definite) vs **"May contain"** (possible) — never "safe"/"danger".
- **Never red or green** anywhere in the UI.

Safety palette per mode (light / dark[=dim] / black):
| token | light | dark (dim) | black |
|---|---|---|---|
| amber | #E89318 | #F0A23A | #FFB23D |
| unknownInk | #8E857A | #9AA1AD | #8A93A2 |
| allergen rail / fg | #D2870F / #96640F | #E0A030 / #F0C079 | #FFB23D / #FFCE85 |
| allergen chipBg | #FDEBC9 | rgba(224,160,48,.18) | rgba(255,178,61,.16) |
| intolerance rail / fg | #CA6A2C / #A1531F | #DE8048 / #EDA777 | #FF9352 / #FFB68A |
| intolerance chipBg | #FBE2CC | rgba(222,128,72,.18) | rgba(255,147,82,.16) |
| goal rail / fg | #6A7396 / #4D5772 | #8C97B8 / #B6C0D6 | #A6B2D6 / #C7D0E8 |
| goal chipBg | #E7E9F1 | rgba(140,151,184,.20) | rgba(166,178,214,.18) |

(Note: in `dim` mode the safety palette uses the `dark` column, while accent uses its own `dim` triplet.)

---

## Screens / Views
The phone canvas is **390 × 844** (iPhone-class), scaled to fit and letterboxed on `stage`.
A 46px status bar sits on top; tab screens have a bottom tab bar; everything between scrolls.

1. **Welcome** — first impression, leads to Scan. **Bespoke layout per direction**:
   - *precision*: mono kicker "Clinical-grade label reading", 37px headline "Know exactly what's inside.", and a live "Sample reading" specimen card showing two findings.
   - *signal*: 62px headline "Scan it. / Know it." + an accent stat block (2.4s avg read · 120k labels).
   - *hearth*: lifestyle image slot, "Trusted by allergy families" pill, serif headline "Care that reads *every* label."
   - Primary "Get started" + ghost "I already have an account". SafetyNote: "Anvara helps you read labels — it doesn't replace medical or allergy advice."

2. **Scan** — camera viewfinder, family session, capture. **Bespoke per direction**:
   - *precision*: mono HUD (READER 2.4 · AUTO, ISO/f-stop, FOCUS LOCKED strip), 16px-radius viewfinder, hollow ring shutter labelled CAPTURE.
   - *signal*: big "Scan" title, accent-coloured corner brackets, full-width "Capture label" CTA + "Upload from photos".
   - *hearth*: viewfinder nested in a soft padded surface frame, round filled shutter.
   - All: corner brackets, amber scan line (animates top 10%→72%), "Scanning for" + member chips + Add. SafetyNote: "Reads the printed label — check the packaging too."

3. **Processing** — transitional. Spinner (accent arc on `line` track) with amber dot centre; four sequential check-off steps ("Reading the label…", "Looking for peanuts and almonds…", "Checking for milk…", "Putting your results together…"); auto-advances to Result (~640–720ms per step).

4. **Result** — the payoff. Header (back / "Results"), product row (label thumb + "Harvest Trail Granola Bar" / "Field & Oat Co. · just now"), session chips, then **MatchBar** cards grouped by category, an "Could not verify" section (unknownInk), a SafetyNote, and "Add to diary" CTA. Tapping any finding opens the **InfoSheet**.

5. **InfoSheet** (bottom sheet over Result) — grabber, "{Contains|May contain} · {category}" mono label + amber dot, big ingredient name + technical name, "Also labeled as" alias chips, "In your profile" correlation panel (panel bg), disclaimer "Reflects your declared profile. Not medical or safety advice.", Close.

6. **Diary** — personal food record. **Bespoke per direction**:
   - *precision*: mono 3-up stat strip (32 Scans / 8 Flagged / May 26 Since), hairline calendar with outline "today", ledger rows (rail + mono time + name + dots).
   - *signal*: giant accent "32 scans saved this month" hero, chunky rounded calendar, bold entry cards.
   - *hearth*: italic journal intro in accentSoft, soft circular-day calendar, vertical timeline of entries with rail dots.
   - SafetyNote: "A private record to help you remember — not medical advice."

7. **Patterns** — "what shows up most." Per-direction insight hero (signal: accent block; hearth: italic serif w/ rule; precision: bordered mono card), then a ranked frequency list (rank, name, bar in category rail colour, count). SafetyNote: "Gentle observations from your scans — not health guidance."

8. **Profile** — family profiles. Avatar row (circle = adult, rounded-square = child, + Add), grouped chips (Allergens / Intolerances / Goals, each chip = category dot + label), an **Appearance** entry row, then an "Unlock Anvara Plus" accent card → Paywall. SafetyNote: "Profiles guide each scan — confirm allergies with your care team."

9. **Appearance** (new) — in-app theming. Live preview card (a sample finding + a Primary button), then **Mode** (3 swatch buttons), **Direction** (3 rows with "Aa" set in each direction's head font + name + note), **Accent colour** (6-swatch grid). Each writes through to the same store the app reads, so everything recolours live. Footer: "Safety colours — the amber finding dot and category tints — never change."

10. **Paywall** — accent header ("Protect everyone you love."), Monthly/Yearly toggle (Yearly shows "SAVE 40%"), two plan cards (Individual $4.99/$2.99 · Family $9.99/$5.99, Family = MOST POPULAR), selected-plan feature list, "Start free trial" CTA, fine print + SafetyNote "Anvara supports your choices — it isn't a medical device."

## Shared components (atoms)
`Status` (faux status bar) · `Btn` (variants: primary/soft/ghost/outline/light; sizes lg=54h, sm=46h; radius `btnR`) · `Logo` (accent rounded-square mark + wordmark) · `AmberDot` (the safety dot, optional ring) · `Avatar` (circle adult / rounded-square child; childBg #E7D9C4, childFg #8A6B3D) · `SessionChip` · `Overline` (mono, 10.5px, 1.4px tracking, uppercase) · `Card` (respects `card` style) · `Slot` (striped image placeholder + mono caption) · `SafetyNote` (info glyph + 11.5px ink3 line — the gentle disclaimer; `center` and `top` variants) · `TabBar` (Scan/Diary/Patterns/Profile) · `MatchBar` + `InfoSheet` (Result).

## Interactions & Behavior
- **Navigation**: single `view` state + `go(v)`. Tab bar switches scan/diary/patterns/profile. Welcome→Scan→Processing→(auto)Result→Diary. Profile→Appearance / Paywall.
- **Processing auto-advance**: setTimeout chain, ~640ms first step then ~720ms each, →Result after last.
- **Scan line**: `@keyframes an-scan` top 10%→72%, 2.2s ease-in-out alternate infinite. Amber pulse dot on the "hold steady" pill (`an-pulse`, 1.3s).
- **Match cards** enter with `an-up` (translateY 10px + fade, .45s). Bottom sheet enters with `an-sheet` (translateY 34px, .3s). Theme changes cross-fade via `an-vfade` (.34s) keyed on dir+accent+mode+view.
- **Press feedback**: `.press` scales to .975 on active; `.tap` tints bg on active. Min hit target 44px throughout.
- **Appearance controls** mutate theme keys (`direction`/`accent`/`mode`) → whole app recolours immediately.
- **prefers-reduced-motion**: gate entrance animations; show end-state.

## State Management
- `view: string` — current screen.
- `theme: { direction, accent, mode }` — the three axes; persist to device storage so the user's Appearance choice survives relaunch.
- `start` — which screen the app opens on (prototype/dev convenience; production opens on Welcome first-run else Scan).
- Result/Paywall hold local UI state (open sheet item; selected plan `family`; billing cycle `year`). Profile holds `activeMember`.
- Real app needs: OCR/label-read pipeline, ingredient→allergen matching against profiles, scan history (diary), per-member profile CRUD, subscription/entitlement state.

## Design Tokens
All enumerated in the tables above. Spacing is an informal 4px-ish rhythm (common paddings 13–24px, gaps 6–14px). Type scale (px): overline 10.5 · caption 11–12 · body 13.5–16 · button 15–16 · titles 17–22 · screen headlines 28–62 (direction-dependent). Radii: see `radius`/`btnR` per direction; pills use 999. Shadows: `shadow` / `shadowSoft` per direction; `glow` in black mode.

## Assets
- **Icons**: inline SVG line set in `app3/system.jsx` (`I` object) — scan, back, chev, check, shield, spark, diary, pulse, user, edit, plus, x, flash, palette, info. Rounded, friendly stroke style (~1.6–1.9 weight). Replace with the codebase's icon library, matching weight/roundness.
- **Images**: product-label and lifestyle photos are `Slot` placeholders (striped) — supply real assets.
- **Fonts**: Hanken Grotesk (UI body, all directions), IBM Plex Sans + IBM Plex Mono (precision), Space Grotesk + Spline Sans Mono (signal), Source Serif 4 + Spline Sans Mono (hearth). All on Google Fonts.
- No Anthropic brand assets are used.

## Files (in this bundle)
- `Anvara - Redesign.html` — entry point; loads fonts, React/Babel, wires the app, hosts the Tweaks panel (direction/accent/mode/screen-jump).
- `app3/system.jsx` — **the theme system** (`DIRS`, `DARK`, `BLACK`, `ACCENTS`, `CATS`, `buildS`) + all shared atoms + icon set. **Port this first.**
- `app3/screens.jsx` — Welcome (×3 bespoke), Processing, Result + MatchBar + InfoSheet, Paywall.
- `app3/screens-tabs.jsx` — Scan (×3), Diary (×3), Patterns, Profile, Appearance.
- `tweaks-panel.jsx` — prototype-only control panel host (not part of the product).

> Reference order for a developer: read `system.jsx` (tokens + atoms) → `screens.jsx` → `screens-tabs.jsx`. The HTML file just mounts them.
