// screens-tabs.jsx — the four tab screens, each composed bespoke per direction so the
// three looks read as genuinely different products, not a recolor.
//   Scan    — Precision: lab instrument · Signal: bold capture CTA · Hearth: calm warm frame
//   Diary   — Precision: ledger/record · Signal: big stat hero · Hearth: journal timeline
//   Patterns/Profile — per-direction hero + treatment, shared list bodies
// Reads atoms/system from window (system.jsx).

const FAMILY = [{ name: 'Maya', role: 'You' }, { name: 'Theo', child: true, role: 'Child' }, { name: 'Ava', child: true, role: 'Child' }];
const MEMBERS = [{ name: 'Maya' }, { name: 'Theo', child: true }];

// ════════════════════════════════════════ SCAN ════════════════════════════════════════
function Scan({ S, go }) {
  if (S.dir === 'signal') return <ScanSignal S={S} go={go} />;
  if (S.dir === 'hearth') return <ScanHearth S={S} go={go} />;
  return <ScanPrecision S={S} go={go} />;
}

// Shared viewfinder. `brackets` = corner color, `r` = radius, `hud` = show mono HUD
function Viewfinder({ S, r, brackets, hud, instruction }) {
  return (
    <div style={{ flex: 1, borderRadius: r, position: 'relative', overflow: 'hidden', background: S.dark, minHeight: 280 }}>
      <div style={{ position: 'absolute', inset: '20% 15%', borderRadius: 10, boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.14)', background: 'rgba(255,255,255,.04)' }} />
      {['tl', 'tr', 'bl', 'br'].map((k) => {
        const pos = { tl: { top: '7%', left: '7%' }, tr: { top: '7%', right: '7%' }, bl: { bottom: '7%', left: '7%' }, br: { bottom: '7%', right: '7%' } }[k];
        const rot = { tl: 0, tr: 90, bl: 270, br: 180 }[k];
        return <svg key={k} width="30" height="30" viewBox="0 0 32 32" fill="none" stroke={brackets} strokeWidth="3" strokeLinecap="round" style={{ position: 'absolute', ...pos, transform: `rotate(${rot}deg)`, opacity: .95 }}><path d="M3 13V5a2 2 0 0 1 2-2h8"/></svg>;
      })}
      <div style={{ position: 'absolute', left: '15%', right: '15%', height: 2, background: `linear-gradient(90deg, transparent, ${S.amber}, transparent)`, animation: 'an-scan 2.2s ease-in-out infinite alternate' }} />
      {hud && (
        <React.Fragment>
          <span style={{ position: 'absolute', top: 12, left: 13, fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.5px', color: 'rgba(255,255,255,.6)' }}>READER 2.4 · AUTO</span>
          <span style={{ position: 'absolute', bottom: 52, left: 13, fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.5px', color: 'rgba(255,255,255,.55)' }}>ISO 200 · f/2.0</span>
          <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: 14, height: 14, borderRadius: '50%', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.5)' }} />
        </React.Fragment>
      )}
      {instruction && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 16, display: 'flex', justifyContent: 'center' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '9px 14px', borderRadius: 999, background: 'rgba(0,0,0,.45)', backdropFilter: 'blur(6px)', fontFamily: S.body, fontWeight: 700, fontSize: 13, color: '#fff' }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: S.amber, animation: 'an-pulse 1.3s infinite' }} />{instruction}
          </div>
        </div>
      )}
    </div>
  );
}

// Precision — lab instrument: mono header strip, HUD reticle, precise ring shutter
function ScanPrecision({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '2px 20px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 22, letterSpacing: S.headLs, color: S.ink }}>Scan a label</span>
          <div style={{ width: 36, height: 36, borderRadius: 8, background: S.panel, display: 'grid', placeItems: 'center' }}>{I.flash(S.accentDeep, 17)}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', borderRadius: 9, marginBottom: 12, boxShadow: `inset 0 0 0 1px ${S.line}` }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontFamily: S.mono, fontSize: 10.5, letterSpacing: '.6px', color: S.ink2 }}><span style={{ width: 7, height: 7, borderRadius: '50%', background: S.accent, animation: 'an-pulse 1.2s infinite' }} />FOCUS LOCKED</span>
          <span style={{ fontFamily: S.mono, fontSize: 10.5, letterSpacing: '.6px', color: S.ink3 }}>ON-DEVICE</span>
        </div>
        <Viewfinder S={S} r={16} brackets={S.onAccent} hud instruction="Hold steady over the ingredients" />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '14px 0 14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexWrap: 'wrap' }}>
            <span style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '.8px', textTransform: 'uppercase', color: S.ink3 }}>Targets</span>
            {MEMBERS.map((m) => <SessionChip key={m.name} S={S} name={m.name} child={m.child} />)}
          </div>
          <button className="press" style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: S.body, fontWeight: 700, fontSize: 13, color: S.accent }}>{I.plus(S.accent, 14)}Add</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
          <button className="press" onClick={() => go('processing')} aria-label="Capture" style={{ width: 68, height: 68, borderRadius: '50%', background: S.surface, display: 'grid', placeItems: 'center', boxShadow: `inset 0 0 0 2px ${S.line}, ${S.shadowSoft}` }}>
            <span style={{ width: 50, height: 50, borderRadius: '50%', background: S.accent, boxShadow: `0 0 0 4px ${S.accentSoft}` }} />
          </button>
          <span style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '1.5px', textTransform: 'uppercase', color: S.ink3 }}>Capture</span>
          <SafetyNote S={S} center style={{ marginTop: 6 }}>Reads the printed label — check the packaging too.</SafetyNote>
        </div>
      </div>
    </Screen>
  );
}

// Signal — bold: big title, accent brackets, full-width capture CTA
function ScanSignal({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '0px 20px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 34, letterSpacing: '-1px', color: S.ink, margin: 0, lineHeight: 1 }}>Scan</h1>
            <div style={{ fontFamily: S.body, fontSize: 13.5, fontWeight: 600, color: S.ink2, marginTop: 4 }}>Point at any label</div>
          </div>
          <div style={{ width: 42, height: 42, borderRadius: 13, background: S.panel, display: 'grid', placeItems: 'center' }}>{I.flash(S.accentDeep, 18)}</div>
        </div>
        <Viewfinder S={S} r={26} brackets={S.accent} instruction="Hold steady over the ingredients" />
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexWrap: 'wrap', margin: '16px 0 14px' }}>
          <span style={{ fontFamily: S.body, fontSize: 12.5, fontWeight: 800, color: S.ink3 }}>Scanning for</span>
          {MEMBERS.map((m) => <SessionChip key={m.name} S={S} name={m.name} child={m.child} />)}
          <button className="press" style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontFamily: S.body, fontWeight: 800, fontSize: 12.5, color: S.accent }}>{I.plus(S.accent, 13)}Add</button>
        </div>
        <Btn S={S} onClick={() => go('processing')}>{I.scan(S.onAccent, 19)} Capture label</Btn>
        <Btn S={S} variant="soft" size="sm" onClick={() => go('processing')} style={{ marginTop: 10 }}>Upload from photos</Btn>
        <SafetyNote S={S} center style={{ marginTop: 12 }}>Reads the printed label — check the packaging too.</SafetyNote>
      </div>
    </Screen>
  );
}

// Hearth — calm warm frame, soft tip, gentle shutter
function ScanHearth({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '2px 22px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 25, letterSpacing: S.headLs, color: S.ink }}>Scan a label</span>
          <div style={{ width: 38, height: 38, borderRadius: 11, background: S.panel, display: 'grid', placeItems: 'center' }}>{I.flash(S.accentDeep, 17)}</div>
        </div>
        <div style={{ flex: 1, borderRadius: 22, padding: 9, background: S.surface, boxShadow: S.shadowSoft, display: 'flex' }}>
          <Viewfinder S={S} r={15} brackets={S.onAccent} instruction="Hold steady — we’ll do the reading" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexWrap: 'wrap', margin: '16px 0 14px' }}>
          <span style={{ fontFamily: S.body, fontSize: 12.5, fontWeight: 700, color: S.ink3 }}>Scanning for</span>
          {MEMBERS.map((m) => <SessionChip key={m.name} S={S} name={m.name} child={m.child} />)}
          <button className="press" style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontFamily: S.body, fontWeight: 700, fontSize: 12.5, color: S.accent }}>{I.plus(S.accent, 13)}Add</button>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <button className="press" onClick={() => go('processing')} aria-label="Capture" style={{ width: 72, height: 72, borderRadius: '50%', background: S.accent, display: 'grid', placeItems: 'center', boxShadow: `0 0 0 5px ${S.accentSoft}, 0 8px 20px ${S.accent}40` }}>
            <span style={{ width: 58, height: 58, borderRadius: '50%', boxShadow: `inset 0 0 0 3px ${S.onAccent}` }} />
          </button>
        </div>
        <SafetyNote S={S} center style={{ marginTop: 14 }}>Reads the printed label — check the packaging too.</SafetyNote>
      </div>
    </Screen>
  );
}

// ════════════════════════════════════════ DIARY ════════════════════════════════════════
const DIARY_TAGS = (S) => ({ 3: S.goal.rail, 5: S.amber, 9: S.goal.rail, 12: S.amber, 14: S.intolerance.rail, 18: S.goal.rail, 21: S.amber, 27: S.goal.rail });
const DIARY_ENTRIES = (S) => [
  { name: 'Harvest Trail Granola Bar', time: '10:24', cat: 'allergen', dots: [S.amber, S.intolerance.rail] },
  { name: 'Oat & Honey Crackers', time: '09:02', cat: 'goal', dots: [S.goal.rail] },
];

function Diary({ S, go, onTab }) {
  if (S.dir === 'signal') return <DiarySignal S={S} go={go} onTab={onTab} />;
  if (S.dir === 'hearth') return <DiaryHearth S={S} go={go} onTab={onTab} />;
  return <DiaryPrecision S={S} go={go} onTab={onTab} />;
}

function CalGrid({ S, today = 28, cells }) {
  const days = Array.from({ length: 30 }, (_, i) => i + 1), offset = 5, tags = DIARY_TAGS(S);
  return (
    <React.Fragment>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, marginBottom: 5 }}>{['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <div key={i} style={{ textAlign: 'center', fontFamily: S.mono, fontSize: 10.5, color: S.ink3 }}>{d}</div>)}</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
        {Array.from({ length: offset }).map((_, i) => <div key={'e' + i} />)}
        {days.map((d) => cells(d, tags[d], d === today))}
      </div>
    </React.Fragment>
  );
}

// Precision — ledger/record: mono stat strip, hairline calendar w/ outline today, ledger rows
function DiaryPrecision({ S, go, onTab }) {
  const entries = DIARY_ENTRIES(S);
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', padding: '4px 22px 10px' }}>
        <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 28, letterSpacing: S.headLs, color: S.ink, margin: 0 }}>Diary</h1>
        <div style={{ fontFamily: S.body, fontSize: 13.5, color: S.ink2, marginTop: 3 }}>Your personal food record</div>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 22px 18px' }}>
        <div style={{ display: 'flex', borderRadius: 10, marginBottom: 16, boxShadow: `inset 0 0 0 1px ${S.line}` }}>
          {[['32', 'Scans'], ['8', 'Flagged'], ['May 26', 'Since']].map(([n, l], i) => (
            <div key={l} style={{ flex: 1, padding: '12px 14px', borderLeft: i ? `1px solid ${S.line}` : 'none' }}>
              <div style={{ fontFamily: S.mono, fontSize: 18, fontWeight: 600, color: S.ink, letterSpacing: '-.5px' }}>{n}</div>
              <div style={{ fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.8px', textTransform: 'uppercase', color: S.ink3, marginTop: 3 }}>{l}</div>
            </div>
          ))}
        </div>
        <Card S={S} style={{ padding: '15px 16px 17px', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 }}>
            <span style={{ fontFamily: S.mono, fontSize: 12, letterSpacing: '.6px', textTransform: 'uppercase', color: S.ink2 }}>June 2026</span>
            <div style={{ display: 'flex', gap: 6 }}>{['‹', '›'].map((a) => <span key={a} style={{ width: 28, height: 28, borderRadius: 7, boxShadow: `inset 0 0 0 1px ${S.line}`, color: S.ink2, display: 'grid', placeItems: 'center', fontSize: 14 }}>{a}</span>)}</div>
          </div>
          <CalGrid S={S} cells={(d, tag, isT) => (
            <div key={d} style={{ aspectRatio: '1', borderRadius: 7, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, boxShadow: isT ? `inset 0 0 0 1.5px ${S.accent}` : 'none' }}>
              <span style={{ fontFamily: S.mono, fontSize: 12, fontWeight: isT ? 600 : 400, color: isT ? S.accent : (d > 28 ? S.ink3 : S.ink) }}>{d}</span>
              {tag && !isT && <span style={{ width: 4, height: 4, borderRadius: '50%', background: tag }} />}
            </div>
          )} />
        </Card>
        <div style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '1.2px', textTransform: 'uppercase', color: S.ink3, marginBottom: 4 }}>Today · 28 Jun</div>
        <div style={{ boxShadow: `inset 0 0 0 1px ${S.line}`, borderRadius: 10, overflow: 'hidden' }}>
          {entries.map((e, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', borderTop: i ? `1px solid ${S.lineSoft}` : 'none' }}>
              <span style={{ width: 3, height: 30, borderRadius: 2, background: S[e.cat].rail, flex: '0 0 3px' }} />
              <span style={{ fontFamily: S.mono, fontSize: 11, color: S.ink3, width: 38 }}>{e.time}</span>
              <span style={{ flex: 1, fontFamily: S.body, fontWeight: 700, fontSize: 15, color: S.ink }}>{e.name}</span>
              <span style={{ display: 'flex', gap: 4 }}>{e.dots.map((c, k) => <span key={k} style={{ width: 7, height: 7, borderRadius: '50%', background: c }} />)}</span>
            </div>
          ))}
        </div>
        <Btn S={S} variant="outline" size="sm" onClick={() => go('scan')} style={{ marginTop: 14 }}>{I.scan(S.ink, 17)} Scan something new</Btn>
        <SafetyNote S={S} top style={{ marginTop: 16 }}>A private record to help you remember — not medical advice.</SafetyNote>
      </div>
      <TabBar S={S} active="diary" onChange={onTab} />
    </Screen>
  );
}

// Signal — big stat hero, chunky calendar, bold entry cards
function DiarySignal({ S, go, onTab }) {
  const entries = DIARY_ENTRIES(S);
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', padding: '4px 22px 10px' }}>
        <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 30, letterSpacing: '-1px', color: S.ink, margin: 0 }}>Diary</h1>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 20px 18px' }}>
        <div style={{ borderRadius: S.radius, background: S.accent, padding: '18px 20px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 16, boxShadow: S.glow || `0 14px 30px ${S.accent}30` }}>
          <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 54, lineHeight: .9, letterSpacing: '-2px', color: S.onAccent, fontVariantNumeric: 'tabular-nums' }}>32</div>
          <div style={{ fontFamily: S.body, fontSize: 14.5, fontWeight: 700, color: S.onAccent, lineHeight: 1.3 }}>scans saved<br />this month</div>
        </div>
        <Card S={S} style={{ padding: '16px 16px 18px', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 }}>
            <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 19, letterSpacing: '-.5px', color: S.ink }}>June 2026</span>
            <div style={{ display: 'flex', gap: 6 }}>{['‹', '›'].map((a) => <span key={a} style={{ width: 32, height: 32, borderRadius: 10, background: S.panel, color: S.ink2, display: 'grid', placeItems: 'center', fontSize: 16 }}>{a}</span>)}</div>
          </div>
          <CalGrid S={S} cells={(d, tag, isT) => (
            <div key={d} style={{ aspectRatio: '1', borderRadius: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3, background: isT ? S.accent : (tag ? S.panel : 'transparent') }}>
              <span style={{ fontFamily: S.body, fontSize: 14, fontWeight: isT ? 800 : 600, color: isT ? S.onAccent : (d > 28 ? S.ink3 : S.ink) }}>{d}</span>
              {tag && !isT && <span style={{ width: 6, height: 6, borderRadius: '50%', background: tag }} />}
              {isT && <span style={{ width: 6, height: 6, borderRadius: '50%', background: S.onAccent }} />}
            </div>
          )} />
        </Card>
        <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 16, letterSpacing: '-.3px', color: S.ink, marginBottom: 10 }}>Today</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          {entries.map((e, i) => (
            <Card S={S} style={{ padding: '15px 17px' }} key={i}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{e.dots.map((c, k) => <span key={k} style={{ width: 9, height: 9, borderRadius: '50%', background: c }} />)}<span style={{ fontFamily: S.mono, fontSize: 11.5, color: S.ink3 }}>{e.time}</span></div>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontFamily: S.body, fontSize: 13, fontWeight: 800, color: S.accent }}>{I.edit(S.accent)} Edit</span>
              </div>
              <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 19, letterSpacing: '-.4px', color: S.ink }}>{e.name}</div>
            </Card>
          ))}
        </div>
        <Btn S={S} variant="soft" size="sm" onClick={() => go('scan')} style={{ marginTop: 14 }}>{I.scan(S.accentDeep, 17)} Scan something new</Btn>
        <SafetyNote S={S} top style={{ marginTop: 16 }}>A private record to help you remember — not medical advice.</SafetyNote>
      </div>
      <TabBar S={S} active="diary" onChange={onTab} />
    </Screen>
  );
}

// Hearth — journal: warm intro, soft calendar, vertical timeline of entries
function DiaryHearth({ S, go, onTab }) {
  const entries = DIARY_ENTRIES(S);
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', padding: '4px 24px 10px' }}>
        <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 30, letterSpacing: S.headLs, color: S.ink, margin: 0 }}>Diary</h1>
        <div style={{ fontFamily: S.body, fontSize: 13.5, color: S.ink2, marginTop: 3 }}>Your personal food record</div>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 24px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '15px 17px', borderRadius: S.radius, background: S.accentSoft, marginBottom: 18 }}>
          <span style={{ width: 40, height: 40, borderRadius: '50%', display: 'grid', placeItems: 'center', background: S.surface, boxShadow: S.shadowSoft }}>{I.shield(S.accentDeep, 18)}</span>
          <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 16.5, letterSpacing: S.headLs, color: S.ink, lineHeight: 1.3, fontStyle: 'italic' }}>A quiet record of everything you’ve eaten.</div>
        </div>
        <Card S={S} style={{ padding: '16px 17px 18px', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 }}>
            <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 18, color: S.ink }}>June 2026</span>
            <div style={{ display: 'flex', gap: 6 }}>{['‹', '›'].map((a) => <span key={a} style={{ width: 30, height: 30, borderRadius: '50%', background: S.panel, color: S.ink2, display: 'grid', placeItems: 'center', fontSize: 15 }}>{a}</span>)}</div>
          </div>
          <CalGrid S={S} cells={(d, tag, isT) => (
            <div key={d} style={{ aspectRatio: '1', borderRadius: '50%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, background: isT ? S.accent : (tag ? S.panel : 'transparent') }}>
              <span style={{ fontFamily: S.body, fontSize: 13, fontWeight: isT ? 800 : 500, color: isT ? S.onAccent : (d > 28 ? S.ink3 : S.ink) }}>{d}</span>
              {tag && !isT && <span style={{ width: 5, height: 5, borderRadius: '50%', background: tag }} />}
            </div>
          )} />
        </Card>
        <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 15, fontStyle: 'italic', color: S.ink2, marginBottom: 14 }}>Today · 28 June</div>
        <div style={{ position: 'relative', paddingLeft: 22 }}>
          <div style={{ position: 'absolute', left: 5, top: 6, bottom: 6, width: 2, background: S.line }} />
          {entries.map((e, i) => (
            <div key={i} style={{ position: 'relative', marginBottom: i < entries.length - 1 ? 20 : 0 }}>
              <span style={{ position: 'absolute', left: -22, top: 4, width: 12, height: 12, borderRadius: '50%', background: S[e.cat].rail, boxShadow: `0 0 0 3px ${S.bg}` }} />
              <div style={{ fontFamily: S.mono, fontSize: 11, color: S.ink3, marginBottom: 3 }}>{e.time}</div>
              <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 18, letterSpacing: S.headLs, color: S.ink }}>{e.name}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 6 }}>
                {e.dots.map((c, k) => <span key={k} style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />)}
                <span style={{ fontFamily: S.body, fontSize: 12.5, color: S.ink3 }}>logged</span>
              </div>
            </div>
          ))}
        </div>
        <Btn S={S} variant="soft" size="sm" onClick={() => go('scan')} style={{ marginTop: 20 }}>{I.scan(S.accentDeep, 17)} Scan something new</Btn>
        <SafetyNote S={S} top style={{ marginTop: 16 }}>A private record to help you remember — not medical advice.</SafetyNote>
      </div>
      <TabBar S={S} active="diary" onChange={onTab} />
    </Screen>
  );
}

// ════════════════════════════════════════ PATTERNS ════════════════════════════════════════
function Patterns({ S, onTab }) {
  const rows = [{ name: 'Added sugars', n: 14, cat: 'goal' }, { name: 'Milk', n: 9, cat: 'intolerance' }, { name: 'Peanuts', n: 6, cat: 'allergen' }, { name: 'Soy lecithin', n: 5, cat: 'goal' }, { name: 'Almonds', n: 3, cat: 'allergen' }];
  const signal = S.dir === 'signal', hearth = S.dir === 'hearth';
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', padding: '4px 22px 10px' }}>
        <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 28, letterSpacing: S.headLs, color: S.ink, margin: 0 }}>Patterns</h1>
        <div style={{ fontFamily: S.body, fontSize: 13.5, color: S.ink2, marginTop: 3 }}>What shows up most in your scans</div>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 22px 18px' }}>
        {/* insight hero — distinct per direction */}
        {signal ? (
          <div style={{ borderRadius: S.radius, background: S.accent, padding: '18px 20px', marginBottom: 20, boxShadow: S.glow || `0 14px 30px ${S.accent}30` }}>
            <div style={{ fontFamily: S.mono, fontSize: 10.5, letterSpacing: '1.4px', textTransform: 'uppercase', color: S.onAccent, opacity: .8 }}>This week</div>
            <p style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 22, letterSpacing: '-.6px', lineHeight: 1.2, color: S.onAccent, margin: '10px 0 0' }}>Added sugars led most of the snacks you scanned.</p>
          </div>
        ) : hearth ? (
          <div style={{ padding: '4px 4px 18px', marginBottom: 16, borderBottom: `1px solid ${S.line}` }}>
            <Overline S={S} color={S.accent}>This week</Overline>
            <p style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 23, fontStyle: 'italic', letterSpacing: S.headLs, lineHeight: 1.3, color: S.ink, margin: '10px 0 0' }}>Added sugars came up in most of the snacks you scanned. Just something we noticed.</p>
          </div>
        ) : (
          <div style={{ borderRadius: 10, padding: '16px 17px', marginBottom: 18, boxShadow: `inset 0 0 0 1px ${S.line}` }}>
            <div style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '1px', textTransform: 'uppercase', color: S.accent }}>This week</div>
            <p style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 18, letterSpacing: S.headLs, lineHeight: 1.35, color: S.ink, margin: '9px 0 0' }}>Added sugars came up in most of the snacks you scanned. Just something we noticed.</p>
          </div>
        )}
        <Overline S={S}>Most frequent · last 30 days</Overline>
        <div style={{ marginTop: 12 }}>
          {rows.map((r, i) => (
            <div key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '13px 0', borderBottom: i < rows.length - 1 ? `1px solid ${S.lineSoft}` : 'none' }}>
              <span style={{ fontFamily: S.mono, fontSize: signal ? 15 : 13, fontWeight: signal ? 700 : 400, color: signal ? S.ink : S.ink3, width: signal ? 20 : 16 }}>{i + 1}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: hearth ? S.head : S.body, fontWeight: 700, fontSize: 16, letterSpacing: hearth ? S.headLs : '0', color: S.ink }}>{r.name}</div>
                <div style={{ height: signal ? 8 : 5, borderRadius: 4, background: S.lineSoft, marginTop: 7, overflow: 'hidden' }}><div style={{ width: (r.n / 14 * 100) + '%', height: '100%', borderRadius: 4, background: S[r.cat].rail }} /></div>
              </div>
              <span style={{ fontFamily: signal ? S.head : S.body, fontWeight: 700, fontSize: signal ? 16 : 14, color: S.ink2, fontVariantNumeric: 'tabular-nums' }}>{r.n}×</span>
            </div>
          ))}
        </div>
        <SafetyNote S={S} top style={{ marginTop: 16 }}>Gentle observations from your scans — not health guidance.</SafetyNote>
      </div>
      <TabBar S={S} active="patterns" onChange={onTab} />
    </Screen>
  );
}

// ════════════════════════════════════════ PROFILE ════════════════════════════════════════
function Profile({ S, go, onTab }) {
  const [active, setActive] = React.useState('Maya');
  const groups = [{ t: 'Allergens', cat: 'allergen', items: ['Peanuts · Severe', 'Tree nuts · Severe'] }, { t: 'Intolerances', cat: 'intolerance', items: ['Lactose · Mild'] }, { t: 'Goals', cat: 'goal', items: ['Lower added sugar'] }];
  const hearth = S.dir === 'hearth';
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', padding: '4px 22px 10px' }}>
        <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 28, letterSpacing: S.headLs, color: S.ink, margin: 0, fontStyle: hearth ? 'italic' : 'normal' }}>Profiles</h1>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 22px 18px' }}>
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {FAMILY.map((m) => {
            const on = active === m.name;
            return (
              <button key={m.name} className="press" onClick={() => setActive(m.name)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
                <span style={{ width: 58, height: 58, borderRadius: m.child ? 17 : '50%', display: 'grid', placeItems: 'center', background: m.child ? S.childBg : S.accentSoft, color: m.child ? S.childFg : S.accentDeep, fontFamily: S.head, fontWeight: S.headWt, fontSize: 22, boxShadow: on ? `0 0 0 3px ${S.bg}, 0 0 0 5px ${S.accent}` : 'none' }}>{m.name[0]}</span>
                <span style={{ fontFamily: S.body, fontSize: 13, fontWeight: on ? 800 : 600, color: on ? S.ink : S.ink2 }}>{m.name}</span>
              </button>
            );
          })}
          <button className="press" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
            <span style={{ width: 58, height: 58, borderRadius: 17, display: 'grid', placeItems: 'center', background: S.surface, color: S.ink3, boxShadow: `inset 0 0 0 1.5px ${S.line}` }}>{I.plus(S.ink3, 18)}</span>
            <span style={{ fontFamily: S.body, fontSize: 13, fontWeight: 600, color: S.ink3 }}>Add</span>
          </button>
        </div>
        {groups.map((g) => (
          <div key={g.t} style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <Overline S={S}>{g.t}</Overline>
              <span style={{ fontFamily: S.body, fontSize: 13, fontWeight: 700, color: S.accent }}>Edit</span>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {g.items.map((it) => (
                <span key={it} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, height: 38, padding: '0 14px', borderRadius: 999, background: S[g.cat].chipBg, fontFamily: S.body, fontWeight: 700, fontSize: 14, color: S[g.cat].fg }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: S[g.cat].rail }} />{it}
                </span>
              ))}
            </div>
          </div>
        ))}
        {/* Appearance entry → in-app theming */}
        <button className="press" onClick={() => go('appearance')} style={{ width: '100%', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', marginBottom: 11, borderRadius: S.radius, background: S.surface, boxShadow: S.card === 'border' ? `inset 0 0 0 1px ${S.line}` : S.shadowSoft }}>
          <span style={{ width: 40, height: 40, borderRadius: 12, flex: '0 0 40px', display: 'grid', placeItems: 'center', background: S.accentSoft }}>{I.palette(S.accentDeep, 19)}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 16, color: S.ink }}>Appearance</div>
            <div style={{ fontFamily: S.body, fontSize: 12.5, color: S.ink2, marginTop: 1 }}>Mode, direction &amp; colour</div>
          </div>
          <span style={{ width: 18, height: 18, borderRadius: '50%', background: S.accent, flex: '0 0 18px' }} />
          {I.chev(S.ink3, 18)}
        </button>
        <button className="press" onClick={() => go('paywall')} style={{ width: '100%', textAlign: 'left', marginTop: 0, borderRadius: S.radius, overflow: 'hidden', background: S.accent, boxShadow: S.glow || `0 10px 24px ${S.accent}30` }}>
          <div style={{ padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 13 }}>
            <span style={{ width: 40, height: 40, borderRadius: 12, flex: '0 0 40px', display: 'grid', placeItems: 'center', background: 'rgba(255,255,255,.18)' }}>{I.spark(S.onAccent)}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 16, color: S.onAccent }}>Unlock Anvara Plus</div>
              <div style={{ fontFamily: S.body, fontSize: 12.5, color: S.onAccent, opacity: .9, marginTop: 1 }}>Unlimited scans · 6 profiles · full history</div>
            </div>
            {I.chev(S.onAccent, 18)}
          </div>
        </button>
        <SafetyNote S={S} top style={{ marginTop: 16 }}>Profiles guide each scan — confirm allergies with your care team.</SafetyNote>
      </div>
      <TabBar S={S} active="profile" onChange={onTab} />
    </Screen>
  );
}

// ════════════════════════════════════════ APPEARANCE ════════════════════════════════════════
// In-app theming. Writes through `set(key,val)` to the same store the whole app reads,
// so every surface recolours live. Three controls: Mode, Direction, Accent colour.
const DIR_META = [
  { key: 'precision', name: 'Precision', note: 'Clinical, precise, instrument-like' },
  { key: 'signal', name: 'Signal', note: 'Bold, modern, high-contrast' },
  { key: 'hearth', name: 'Hearth', note: 'Warm, editorial, gentle' },
];
const MODE_META = [['light', 'Light'], ['dim', 'Dim'], ['black', 'Black']];

function Appearance({ S, go, set }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', gap: 10, padding: '2px 18px 12px' }}>
        <button className="press" onClick={() => go('profile')} style={{ width: 38, height: 38, borderRadius: 11, display: 'grid', placeItems: 'center', background: S.panel }}>{I.back(S.ink)}</button>
        <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 19, letterSpacing: S.headLs, color: S.ink }}>Appearance</span>
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '0 22px 24px' }}>
        {/* live preview */}
        <div style={{ borderRadius: S.radius, overflow: 'hidden', marginBottom: 22, boxShadow: S.card === 'border' ? `inset 0 0 0 1px ${S.line}` : S.shadowSoft, background: S.surface }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 15px 12px' }}>
            <span style={{ width: 4, alignSelf: 'stretch', borderRadius: 2, background: S.allergen.rail }} />
            <AmberDot S={S} s={12} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.8px', textTransform: 'uppercase', color: S.allergen.fg }}>Contains</div>
              <div style={{ fontFamily: S.dir === 'hearth' ? S.head : S.body, fontWeight: 700, fontSize: 18, color: S.ink, marginTop: 1 }}>Peanuts</div>
            </div>
            <span style={{ display: 'inline-flex', alignItems: 'center', height: 30, padding: '0 13px', borderRadius: S.btnR, background: S.accent, color: S.onAccent, fontFamily: S.body, fontWeight: 700, fontSize: 12.5 }}>Primary</span>
          </div>
          <div style={{ padding: '0 15px 13px', fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.6px', textTransform: 'uppercase', color: S.ink3 }}>Live preview</div>
        </div>

        {/* Mode */}
        <Overline S={S}>Mode</Overline>
        <div style={{ display: 'flex', gap: 8, margin: '11px 0 22px' }}>
          {MODE_META.map(([k, lbl]) => {
            const on = S.mode === k;
            const swatch = k === 'light' ? '#FFFFFF' : k === 'dim' ? '#1B2230' : '#000000';
            return (
              <button key={k} className="press" onClick={() => set('mode', k)} style={{ flex: 1, borderRadius: 13, padding: '13px 0 11px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9, background: S.surface, boxShadow: on ? `inset 0 0 0 2px ${S.accent}` : `inset 0 0 0 1px ${S.line}` }}>
                <span style={{ width: 30, height: 30, borderRadius: '50%', background: swatch, boxShadow: `inset 0 0 0 1px ${S.line}` }} />
                <span style={{ fontFamily: S.body, fontSize: 13, fontWeight: on ? 800 : 600, color: on ? S.ink : S.ink2 }}>{lbl}</span>
              </button>
            );
          })}
        </div>

        {/* Direction */}
        <Overline S={S}>Direction</Overline>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9, margin: '11px 0 22px' }}>
          {DIR_META.map((d) => {
            const on = S.dir === d.key;
            return (
              <button key={d.key} className="press" onClick={() => set('direction', d.key)} style={{ display: 'flex', alignItems: 'center', gap: 13, textAlign: 'left', padding: '13px 15px', borderRadius: 13, background: S.surface, boxShadow: on ? `inset 0 0 0 2px ${S.accent}` : `inset 0 0 0 1px ${S.line}` }}>
                <span style={{ fontFamily: window.DIRS[d.key].head, fontWeight: window.DIRS[d.key].headWt, fontSize: 24, color: S.ink, width: 30, textAlign: 'center', lineHeight: 1 }}>Aa</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 16, color: S.ink }}>{d.name}</div>
                  <div style={{ fontFamily: S.body, fontSize: 12.5, color: S.ink2, marginTop: 1 }}>{d.note}</div>
                </div>
                <span style={{ width: 22, height: 22, borderRadius: '50%', flex: '0 0 22px', display: 'grid', placeItems: 'center', background: on ? S.accent : 'transparent', boxShadow: on ? 'none' : `inset 0 0 0 2px ${S.line}` }}>{on && I.check(S.onAccent, 12)}</span>
              </button>
            );
          })}
        </div>

        {/* Accent */}
        <Overline S={S}>Accent colour</Overline>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginTop: 11 }}>
          {window.ACCENT_ORDER.map((key) => {
            const a = window.ACCENTS[key]; const on = S.accentKey === key;
            return (
              <button key={key} className="press" onClick={() => set('accent', key)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '13px 0 11px', borderRadius: 13, background: S.surface, boxShadow: on ? `inset 0 0 0 2px ${S.accent}` : `inset 0 0 0 1px ${S.line}` }}>
                <span style={{ width: 34, height: 34, borderRadius: '50%', background: a.swatch, display: 'grid', placeItems: 'center', boxShadow: `0 2px 8px ${a.swatch}40` }}>{on && I.check('#fff', 15)}</span>
                <span style={{ fontFamily: S.body, fontSize: 12, fontWeight: on ? 800 : 600, color: on ? S.ink : S.ink2 }}>{a.name}</span>
              </button>
            );
          })}
        </div>

        <div style={{ fontFamily: S.mono, fontSize: 10.5, color: S.ink3, textAlign: 'center', margin: '22px 0 0', lineHeight: 1.6 }}>Safety colours — the amber finding dot and<br />category tints — never change.</div>
      </div>
    </Screen>
  );
}

Object.assign(window, { Scan, Diary, Patterns, Profile, Appearance });
