// screens.jsx — Welcome (bespoke per direction), Processing, Result + match bar, Paywall.
// The four tab screens (Scan, Diary, Patterns, Profile) live in screens-tabs.jsx.
// Reads atoms/system from window (system.jsx).

// ═══════════════ WELCOME (bespoke per direction) ═══════════════
function Welcome({ S, go }) {
  if (S.dir === 'signal') return <WelcomeSignal S={S} go={go} />;
  if (S.dir === 'hearth') return <WelcomeHearth S={S} go={go} />;
  return <WelcomePrecision S={S} go={go} />;
}

// Precision — clinical instrument: mono kicker, tight headline, a live "specimen" readout card
function WelcomePrecision({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '8px 24px 28px' }}>
        <Logo S={S} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <Overline S={S} color={S.accent}>Clinical-grade label reading</Overline>
          <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 37, lineHeight: 1.08, letterSpacing: S.headLs, color: S.ink, margin: '14px 0 0' }}>Know exactly<br />what’s inside.</h1>
          <p style={{ fontFamily: S.body, fontSize: 16, lineHeight: 1.5, color: S.ink2, margin: '14px 0 22px', maxWidth: 320 }}>Point Anvara at any label. We read it against your family’s allergies and goals — precisely, no verdicts, no guesswork.</p>
          <Card S={S} style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', borderBottom: `1px solid ${S.line}` }}>
              <span style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '1px', textTransform: 'uppercase', color: S.ink3 }}>Sample reading</span>
              <span style={{ fontFamily: S.mono, fontSize: 10, color: S.ink3 }}>02 findings</span>
            </div>
            {[['allergen', 'Contains', 'Peanuts'], ['intolerance', 'May contain', 'Milk']].map(([cat, verb, name], i) => (
              <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '12px 14px', borderTop: i ? `1px solid ${S.lineSoft}` : 'none' }}>
                <span style={{ width: 3, alignSelf: 'stretch', borderRadius: 2, background: S[cat].rail }} />
                <AmberDot S={S} s={11} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: S.mono, fontSize: 9.5, letterSpacing: '.8px', textTransform: 'uppercase', color: S[cat].fg }}>{verb}</div>
                  <div style={{ fontFamily: S.body, fontWeight: 700, fontSize: 16, color: S.ink, marginTop: 1 }}>{name}</div>
                </div>
              </div>
            ))}
          </Card>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Btn S={S} onClick={() => go('scan')}>Get started</Btn>
          <Btn S={S} variant="ghost" size="sm" onClick={() => go('scan')}>I already have an account</Btn>
        </div>
        <SafetyNote S={S} center style={{ marginTop: 13 }}>Anvara helps you read labels — it doesn’t replace medical or allergy advice.</SafetyNote>
      </div>
    </Screen>
  );
}

// Signal — bold fintech: oversized headline, electric block, chunky CTA
function WelcomeSignal({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '8px 24px 26px' }}>
        <Logo S={S} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', paddingTop: 8 }}>
          <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 62, lineHeight: 0.92, letterSpacing: '-2px', color: S.ink, margin: 0 }}>Scan it.<br />Know it.</h1>
          <p style={{ fontFamily: S.body, fontSize: 17, lineHeight: 1.45, color: S.ink2, margin: '20px 0 0', maxWidth: 300 }}>Any label, checked against every allergy and goal in your household — in seconds.</p>
          <div style={{ marginTop: 26, borderRadius: S.radius, background: S.accent, padding: '20px 22px', display: 'flex', alignItems: 'center', gap: 18, boxShadow: S.glow || `0 16px 34px ${S.accent}33` }}>
            <div>
              <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 40, lineHeight: 1, letterSpacing: '-1px', color: S.onAccent, fontVariantNumeric: 'tabular-nums' }}>2.4s</div>
              <div style={{ fontFamily: S.body, fontSize: 12.5, fontWeight: 600, color: S.onAccent, opacity: .85, marginTop: 4 }}>avg. read time</div>
            </div>
            <div style={{ width: 1, alignSelf: 'stretch', background: 'rgba(255,255,255,.25)' }} />
            <div>
              <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 40, lineHeight: 1, letterSpacing: '-1px', color: S.onAccent, fontVariantNumeric: 'tabular-nums' }}>120k</div>
              <div style={{ fontFamily: S.body, fontSize: 12.5, fontWeight: 600, color: S.onAccent, opacity: .85, marginTop: 4 }}>labels in our index</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Btn S={S} onClick={() => go('scan')}>Get started</Btn>
          <Btn S={S} variant="ghost" size="sm" onClick={() => go('scan')}>I already have an account</Btn>
        </div>
        <SafetyNote S={S} center style={{ marginTop: 13 }}>Anvara helps you read labels — it doesn’t replace medical or allergy advice.</SafetyNote>
      </div>
    </Screen>
  );
}

// Hearth — warm editorial: serif headline, soft lifestyle image, refined
function WelcomeHearth({ S, go }) {
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '8px 26px 28px' }}>
        <Logo S={S} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <Slot S={S} label="lifestyle photo" style={{ height: 196, marginBottom: 24 }} r={S.radius} />
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, alignSelf: 'flex-start', padding: '6px 12px', borderRadius: 999, background: S.accentSoft, marginBottom: 16 }}>
            {I.shield(S.accentDeep, 15)}<span style={{ fontFamily: S.body, fontWeight: 700, fontSize: 12, color: S.accentDeep }}>Trusted by allergy families</span>
          </div>
          <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 40, lineHeight: 1.08, letterSpacing: S.headLs, color: S.ink, margin: 0 }}>Care that reads<br /><em style={{ fontStyle: 'italic' }}>every</em> label.</h1>
          <p style={{ fontFamily: S.body, fontSize: 16, lineHeight: 1.55, color: S.ink2, margin: '16px 0 0', maxWidth: 320 }}>Anvara checks each ingredient against your family’s needs — gently, clearly, and always in plain words.</p>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Btn S={S} onClick={() => go('scan')}>Get started</Btn>
          <Btn S={S} variant="ghost" size="sm" onClick={() => go('scan')}>I already have an account</Btn>
        </div>
        <SafetyNote S={S} center style={{ marginTop: 13 }}>Anvara helps you read labels — it doesn’t replace medical or allergy advice.</SafetyNote>
      </div>
    </Screen>
  );
}

// ═══════════════ PROCESSING ═══════════════
function Processing({ S, go }) {
  const steps = ['Reading the label…', 'Looking for peanuts and almonds…', 'Checking for milk…', 'Putting your results together…'];
  const [i, setI] = React.useState(0);
  React.useEffect(() => {
    if (i >= steps.length) { const t = setTimeout(() => go('result'), 360); return () => clearTimeout(t); }
    const t = setTimeout(() => setI((x) => x + 1), i === 0 ? 640 : 720); return () => clearTimeout(t);
  }, [i]);
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 32px 50px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 32 }}>
          <div style={{ width: 76, height: 76, position: 'relative' }}>
            <svg width="76" height="76" viewBox="0 0 76 76" style={{ animation: 'an-spin 1.5s linear infinite' }}>
              <circle cx="38" cy="38" r="32" fill="none" stroke={S.line} strokeWidth="5" />
              <circle cx="38" cy="38" r="32" fill="none" stroke={S.accent} strokeWidth="5" strokeLinecap="round" strokeDasharray="52 160" />
            </svg>
            <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}><AmberDot S={S} s={16} /></div>
          </div>
        </div>
        <Overline S={S} color={S.ink3}><div style={{ textAlign: 'center', marginBottom: 16 }}>Reading your label</div></Overline>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          {steps.map((s, k) => {
            const done = k < i, active = k === i;
            return (
              <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 12, opacity: k > i ? .32 : 1, transition: 'opacity .4s' }}>
                <span style={{ width: 22, height: 22, borderRadius: '50%', flex: '0 0 22px', display: 'grid', placeItems: 'center', background: done ? S.accent : (active ? S.accentSoft : S.surface), boxShadow: done ? 'none' : `inset 0 0 0 1.5px ${S.line}` }}>
                  {done && I.check(S.onAccent, 11)}
                  {active && <span style={{ width: 7, height: 7, borderRadius: '50%', background: S.accent, animation: 'an-pulse 1s infinite' }} />}
                </span>
                <span style={{ fontFamily: S.body, fontSize: 16.5, color: active ? S.ink : S.ink2, fontWeight: active ? 700 : 500 }}>{s}</span>
              </div>
            );
          })}
        </div>
      </div>
    </Screen>
  );
}

// ═══════════════ MATCH BAR (bespoke treatment per direction) ═══════════════
const VERB = { contains: 'Contains', may: 'May contain' };
function MatchBar({ S, data, onOpen }) {
  const pal = S[data.cat];
  const signal = S.dir === 'signal', hearth = S.dir === 'hearth';
  const railW = signal ? 6 : S.dir === 'precision' ? 3 : 0;
  return (
    <Card S={S} style={{ padding: 0, overflow: 'hidden', marginBottom: 12, display: 'flex', animation: 'an-up .45s both' }}>
      {railW > 0 && <div style={{ width: railW, background: pal.rail, flex: `0 0 ${railW}px` }} />}
      <div style={{ flex: 1, padding: signal ? '15px 16px 7px' : '13px 15px 5px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: hearth ? 4 : 3 }}>
          {hearth && <span style={{ width: 9, height: 22, borderRadius: 999, background: pal.rail, flex: '0 0 9px' }} />}
          <AmberDot S={S} s={signal ? 14 : 12} ring={signal} />
          <span style={{ fontFamily: hearth ? S.head : S.body, fontWeight: 800, fontSize: signal ? 13 : 12, letterSpacing: hearth ? '.2px' : '.4px', textTransform: hearth ? 'none' : 'uppercase', color: pal.fg }}>{data.label}</span>
          {data.beta && <span style={{ fontFamily: S.mono, fontSize: 9.5, fontWeight: 600, letterSpacing: '.5px', color: pal.fg, background: pal.chipBg, padding: '2px 6px', borderRadius: 5 }}>BETA</span>}
        </div>
        {data.items.map((it, i) => (
          <button key={i} className="tap" onClick={() => onOpen(data, it)} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, width: '100%', textAlign: 'left', padding: '9px 0', borderTop: i ? `1px solid ${S.lineSoft}` : 'none', borderRadius: 6 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: S.mono, fontSize: 10, letterSpacing: '1px', textTransform: 'uppercase', color: pal.fg, marginBottom: 3 }}>{VERB[it.kind] || VERB.contains}</div>
              <div style={{ fontFamily: hearth ? S.head : S.body, fontWeight: hearth ? S.headWt : 700, fontSize: signal ? 22 : 18, color: S.ink, lineHeight: 1.1, letterSpacing: signal ? '-.4px' : '0' }}>{it.common}</div>
              {it.tech && <div style={{ fontFamily: S.body, fontSize: 13, color: S.ink2, marginTop: 2 }}>({it.tech})</div>}
              {it.tags && (
                <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                  {it.tags.map((t) => (
                    <span key={t.name} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, height: 22, padding: '0 9px 0 5px', borderRadius: 999, background: S.panel, fontFamily: S.body, fontWeight: 700, fontSize: 11.5, color: S.ink2 }}>
                      <Avatar S={S} name={t.name} child={t.child} size={15} />{t.name}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <span style={{ marginTop: 12 }}>{I.chev(pal.rail, 16)}</span>
          </button>
        ))}
      </div>
    </Card>
  );
}

const RESULT_DATA = {
  product: 'Harvest Trail Granola Bar', brand: 'Field & Oat Co.',
  findings: [
    { cat: 'allergen', label: 'Allergen match', items: [
      { kind: 'contains', common: 'Peanuts', tech: 'Arachis hypogaea', tags: [{ name: 'Maya' }, { name: 'Theo', child: true }], aka: ['groundnuts', 'arachis oil', 'mandelona'], correlation: 'Matches Peanuts on 2 profiles this session — Maya and Theo.' },
      { kind: 'contains', common: 'Almonds', tech: 'Prunus dulcis', tags: [{ name: 'Maya' }], aka: ['almond flour', 'marzipan'], correlation: 'Matches Tree nuts on Maya’s profile.' },
    ] },
    { cat: 'intolerance', label: 'Intolerance note', beta: true, items: [
      { kind: 'may', common: 'Milk', tech: 'listed as “whey”', tags: [{ name: 'Maya' }], aka: ['whey', 'casein', 'milk solids'], correlation: 'Relates to Lactose on Maya’s profile. Whey is milk-derived.' },
    ] },
  ],
  unverified: ['Natural flavoring', 'Rosemary extract'],
};

// ═══════════════ RESULT ═══════════════
function Result({ S, go }) {
  const [sheet, setSheet] = React.useState(null);
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 16px 10px' }}>
        <button className="press" onClick={() => go('scan')} style={{ width: 38, height: 38, borderRadius: 11, display: 'grid', placeItems: 'center', background: S.panel }}>{I.back(S.ink)}</button>
        <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 17, color: S.ink }}>Results</span>
        <div style={{ width: 38 }} />
      </div>
      <div className="an-scroll" style={{ flex: 1, padding: '2px 18px 24px' }}>
        <div style={{ display: 'flex', gap: 13, alignItems: 'center', marginBottom: 13 }}>
          <Slot S={S} label="label" style={{ width: 52, height: 52, flex: '0 0 52px' }} r={13} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 20, letterSpacing: S.headLs, color: S.ink, lineHeight: 1.1 }}>{RESULT_DATA.product}</div>
            <div style={{ fontFamily: S.body, fontSize: 13, color: S.ink2, marginTop: 2 }}>{RESULT_DATA.brand} · just now</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 14 }}>
          <span style={{ fontFamily: S.body, fontSize: 12, fontWeight: 700, color: S.ink3 }}>This session</span>
          <SessionChip S={S} name="Maya" /><SessionChip S={S} name="Theo" child />
        </div>
        <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 17, letterSpacing: S.headLs, color: S.ink, margin: '0 0 13px' }}>Here’s what we found in what we could read.</div>
        {RESULT_DATA.findings.map((f, i) => <MatchBar key={i} S={S} data={f} onOpen={(finding, item) => setSheet({ finding, item })} />)}
        <div style={{ marginTop: 4, marginBottom: 12 }}>
          <div style={{ fontFamily: S.body, fontWeight: 700, fontSize: 12.5, color: S.ink2, marginBottom: 5 }}>Could not verify</div>
          <div style={{ fontFamily: S.body, fontSize: 13.5, color: S.unknownInk, lineHeight: 1.5 }}>{RESULT_DATA.unverified.join(' · ')}</div>
          <div style={{ fontFamily: S.body, fontSize: 12, color: S.ink3, marginTop: 6, lineHeight: 1.5 }}>Not in our current database. Connect to the internet or check the label.</div>
        </div>
        <SafetyNote S={S} top style={{ marginBottom: 14 }}>Based on the label as we read it — always check the original packaging. Not medical advice · data current to May 28, 2026.</SafetyNote>
        <Btn S={S} onClick={() => go('diary')}>{I.check(S.onAccent, 18)} Add to diary</Btn>
      </div>
      <InfoSheet S={S} data={sheet} onClose={() => setSheet(null)} />
    </Screen>
  );
}

// ═══════════════ INFO SHEET ═══════════════
function InfoSheet({ S, data, onClose }) {
  if (!data) return null;
  const { finding, item } = data; const pal = S[finding.cat];
  return (
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, zIndex: 40, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', background: 'rgba(20,18,24,.36)' }}>
      <div onClick={(e) => e.stopPropagation()} className="an-scroll" style={{ background: S.surface, borderRadius: '26px 26px 0 0', maxHeight: '86%', boxShadow: '0 -10px 40px rgba(20,18,24,.2)', animation: 'an-sheet .3s cubic-bezier(.2,.8,.25,1) both', padding: '10px 22px 28px' }}>
        <div style={{ width: 40, height: 5, borderRadius: 3, background: S.line, margin: '0 auto 16px' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 13 }}>
          <AmberDot S={S} /><span style={{ fontFamily: S.mono, fontSize: 10.5, letterSpacing: '1px', textTransform: 'uppercase', color: pal.fg }}>{VERB[item.kind]} · {finding.label}</span>
        </div>
        <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 30, letterSpacing: S.headLs, color: S.ink, lineHeight: 1.05 }}>{item.common}</div>
        {item.tech && <div style={{ fontFamily: S.body, fontSize: 14.5, color: S.ink2, marginTop: 4 }}>({item.tech})</div>}
        <div style={{ marginTop: 18 }}>
          <Overline S={S}>Also labeled as</Overline>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginTop: 9 }}>
            {item.aka.map((a) => <span key={a} style={{ fontFamily: S.body, fontSize: 13.5, fontWeight: 600, color: S.ink2, padding: '5px 11px', borderRadius: 999, background: S.panel }}>{a}</span>)}
          </div>
        </div>
        <div style={{ marginTop: 18, padding: '15px 16px', borderRadius: 14, background: S.panel }}>
          <Overline S={S}>In your profile</Overline>
          <div style={{ fontFamily: S.body, fontSize: 15, lineHeight: 1.5, color: S.ink, marginTop: 8 }}>{item.correlation}</div>
        </div>
        <div style={{ fontFamily: S.mono, fontSize: 10.5, color: S.ink3, textAlign: 'center', margin: '18px 0 16px', lineHeight: 1.5 }}>Reflects your declared profile. Not medical or safety advice.</div>
        <Btn S={S} variant="outline" onClick={onClose}>Close</Btn>
      </div>
    </div>
  );
}

// ═══════════════ PAYWALL ═══════════════
const PLANS = {
  individual: {
    name: 'Individual', tag: 'For one person',
    glyph: (c, s) => I.user(c, s),
    price: { month: '4.99', year: '2.99' }, annual: '35.88', profiles: '1 profile',
    feats: ['Unlimited label scans', 'Full history & patterns', 'Works offline in the store', 'Priority database updates'],
  },
  family: {
    name: 'Family', tag: 'For the whole household', popular: true,
    glyph: (c, s = 19) => <svg width={s} height={s} viewBox="0 0 21 21" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="7" cy="7.5" r="2.6"/><circle cx="14.5" cy="8" r="2.2"/><path d="M2.8 16c.5-2.6 2.2-4 4.2-4s3.7 1.4 4.2 4M12.5 15.6c.5-2.2 1.9-3.1 3.4-3.1 1.7 0 2.8 1 3.3 3.1"/></svg>,
    price: { month: '9.99', year: '5.99' }, annual: '71.88', profiles: 'Up to 6 profiles',
    feats: ['Everything in Individual', 'Up to 6 family profiles', 'Child Mode for kids', 'Shared family scan sessions', 'One bill for everyone'],
  },
};

function Paywall({ S, go }) {
  const [plan, setPlan] = React.useState('family');
  const [cycle, setCycle] = React.useState('year');
  const P = PLANS[plan];
  return (
    <Screen S={S} scroll={false}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div style={{ background: S.accent, padding: '6px 24px 24px', boxShadow: S.isBlack ? `0 10px 40px ${S.accent}55` : 'none' }}>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}><button className="press" onClick={() => go('profile')} aria-label="Close" style={{ width: 34, height: 34, display: 'grid', placeItems: 'center' }}>{I.x('rgba(255,255,255,.85)', 20)}</button></div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '6px 11px', borderRadius: 999, background: 'rgba(255,255,255,.18)', marginBottom: 13 }}>{I.spark(S.onAccent)}<span style={{ fontFamily: S.body, fontWeight: 700, fontSize: 12.5, color: S.onAccent }}>Anvara Plus</span></div>
          <h1 style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 31, lineHeight: 1.08, letterSpacing: S.headLs, color: S.onAccent, margin: 0 }}>Protect everyone<br />you love.</h1>
          <p style={{ fontFamily: S.body, fontSize: 14.5, lineHeight: 1.5, color: S.onAccent, opacity: .9, margin: '11px 0 0', maxWidth: 300 }}>Pick the plan that fits your household. Try any plan free for 7 days.</p>
        </div>
        <div className="an-scroll" style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '18px 22px 22px' }}>
          <div style={{ display: 'flex', alignSelf: 'center', background: S.panel, borderRadius: 999, padding: 4, marginBottom: 18 }}>
            {[['month', 'Monthly'], ['year', 'Yearly']].map(([k, lbl]) => {
              const on = cycle === k;
              return (
                <button key={k} className="press" onClick={() => setCycle(k)} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, height: 36, padding: '0 16px', borderRadius: 999, background: on ? S.surface : 'transparent', boxShadow: on ? S.shadowSoft : 'none', fontFamily: S.body, fontWeight: 700, fontSize: 13.5, color: on ? S.ink : S.ink2 }}>
                  {lbl}{k === 'year' && <span style={{ fontFamily: S.body, fontWeight: 800, fontSize: 10.5, color: S.accentDeep, background: S.accentSoft, padding: '2px 7px', borderRadius: 999 }}>SAVE 40%</span>}
                </button>
              );
            })}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {Object.entries(PLANS).map(([key, pl]) => {
              const on = plan === key;
              return (
                <button key={key} className="press" onClick={() => setPlan(key)} style={{ textAlign: 'left', borderRadius: S.radius, padding: '15px 16px', background: S.surface, position: 'relative',
                  boxShadow: on ? `inset 0 0 0 2px ${S.accent}${S.isBlack ? ', 0 8px 26px ' + S.accent + '40' : ''}` : `inset 0 0 0 1.5px ${S.line}` }}>
                  {pl.popular && <span style={{ position: 'absolute', top: -9, right: 14, fontFamily: S.body, fontWeight: 800, fontSize: 10, letterSpacing: '.4px', color: S.onAccent, background: S.accent, padding: '3px 9px', borderRadius: 999 }}>MOST POPULAR</span>}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ width: 22, height: 22, borderRadius: '50%', flex: '0 0 22px', display: 'grid', placeItems: 'center', background: on ? S.accent : 'transparent', boxShadow: on ? 'none' : `inset 0 0 0 2px ${S.line}` }}>{on && I.check(S.onAccent, 12)}</span>
                    <span style={{ width: 38, height: 38, borderRadius: 11, flex: '0 0 38px', display: 'grid', placeItems: 'center', background: S.accentSoft }}>{pl.glyph(S.accentDeep, 19)}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 17, color: S.ink, letterSpacing: S.headLs }}>{pl.name}</div>
                      <div style={{ fontFamily: S.body, fontSize: 12.5, color: S.ink2, marginTop: 1 }}>{pl.tag} · {pl.profiles}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: 21, color: S.ink, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>${pl.price[cycle]}</div>
                      <div style={{ fontFamily: S.body, fontSize: 11, color: S.ink3, marginTop: 2 }}>/mo</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
          <div style={{ marginTop: 18 }}>
            <Overline S={S}>{P.name} includes</Overline>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginTop: 12 }}>
              {P.feats.map((f) => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <span style={{ width: 22, height: 22, borderRadius: '50%', flex: '0 0 22px', display: 'grid', placeItems: 'center', background: S.accentSoft }}>{I.check(S.accentDeep, 13)}</span>
                  <span style={{ fontFamily: S.body, fontWeight: 600, fontSize: 14.5, color: S.ink }}>{f}</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, minHeight: 18 }} />
          <Btn S={S} onClick={() => go('diary')} style={{ marginTop: 16 }}>Start free trial · {P.name}</Btn>
          <div style={{ fontFamily: S.body, fontSize: 11.5, color: S.ink3, textAlign: 'center', marginTop: 11, lineHeight: 1.5 }}>
            7 days free, then {cycle === 'year' ? `$${P.annual}/yr` : `$${P.price.month}/mo`}. Cancel anytime. <span style={{ color: S.accentDeep, fontWeight: 700 }}>Restore purchases</span>
          </div>
          <SafetyNote S={S} center style={{ marginTop: 12 }}>Anvara supports your choices — it isn’t a medical device.</SafetyNote>
        </div>
      </div>
    </Screen>
  );
}

Object.assign(window, { Welcome, Processing, Result, Paywall });
