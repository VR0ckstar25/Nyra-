// system.jsx — redesigned design system for Anvara.
// THREE INDEPENDENT AXES the whole app reads from:
//   Direction (Precision / Signal / Hearth) — type, shape, layout, neutral palette
//   Accent    (Cobalt / Indigo / Plum / Turquoise / Fuchsia / Grape) — CTA & selection colour
//   Mode      (Light / Dim / Black) — surface luminance
// Any direction × any accent × any mode is valid. FIXED safety system is shared and
// NEVER themed: amber dot = a finding is present; category shown by RAIL + label colour;
// "Contains" vs "May contain" wording; never red/green; colour always backed by a label.

const BODY = "'Hanken Grotesk', system-ui, sans-serif";

// ── DIRECTION: structural tokens (no accent — accent is resolved separately) ──
const DIRS = {
  precision: {
    key: 'precision', name: 'Precision',
    bg: '#F5F8FA', panel: '#E9F0F5', surface: '#FFFFFF', dark: '#0B1117',
    ink: '#0E1822', ink2: '#4C5A66', ink3: '#8896A2', line: '#E0E8EE', lineSoft: '#EEF3F7',
    head: "'IBM Plex Sans', sans-serif", body: BODY, mono: "'IBM Plex Mono', ui-monospace, monospace",
    headWt: 600, headLs: '-0.3px', radius: 12, btnR: 10, card: 'border',
    shadow: '0 1px 2px rgba(14,24,34,.05), 0 6px 18px rgba(14,24,34,.05)',
    shadowSoft: '0 1px 2px rgba(14,24,34,.04)', stage: '#DCE4EB',
  },
  signal: {
    key: 'signal', name: 'Signal',
    bg: '#FFFFFF', panel: '#F0F1F8', surface: '#FFFFFF', dark: '#0A0B14',
    ink: '#0B0D16', ink2: '#525870', ink3: '#9095AC', line: '#E7E8F1', lineSoft: '#F2F2F8',
    head: "'Space Grotesk', sans-serif", body: BODY, mono: "'Spline Sans Mono', ui-monospace, monospace",
    headWt: 700, headLs: '-1px', radius: 22, btnR: 16, card: 'shadow',
    shadow: '0 1px 2px rgba(11,13,22,.05), 0 16px 34px rgba(11,13,22,.10)',
    shadowSoft: '0 1px 2px rgba(11,13,22,.05), 0 3px 10px rgba(11,13,22,.06)', stage: '#ECECF4',
  },
  hearth: {
    key: 'hearth', name: 'Hearth',
    bg: '#FAF6F0', panel: '#F0E8DD', surface: '#FFFFFF', dark: '#1E1712',
    ink: '#241E18', ink2: '#5E564C', ink3: '#9C9183', line: '#EAE2D5', lineSoft: '#F3ECE1',
    head: "'Source Serif 4', Georgia, serif", body: BODY, mono: "'Spline Sans Mono', ui-monospace, monospace",
    headWt: 600, headLs: '-0.2px', radius: 18, btnR: 13, card: 'soft',
    shadow: '0 1px 2px rgba(36,30,24,.05), 0 12px 28px rgba(36,30,24,.08)',
    shadowSoft: '0 1px 2px rgba(36,30,24,.05), 0 2px 8px rgba(36,30,24,.05)', stage: '#ECE4D8',
  },
};

// ── DIRECTION × MODE neutral overlays (no accent) ──
const DARK = {
  precision: { bg:'#0B1018', panel:'#161D27', surface:'#121925', dark:'#070B11', ink:'#EAF0F6', ink2:'#A2AEBC', ink3:'#65717F', line:'#222B38', lineSoft:'#1A222E', stage:'#0C121A', shadow:'0 1px 2px rgba(0,0,0,.45), 0 12px 30px rgba(0,0,0,.5)', shadowSoft:'0 1px 3px rgba(0,0,0,.4)' },
  signal:    { bg:'#0C0D17', panel:'#191A28', surface:'#14151F', dark:'#08090F', ink:'#EEEEF8', ink2:'#A6A8C0', ink3:'#6C6E86', line:'#262640', lineSoft:'#1C1C2E', stage:'#101120', shadow:'0 1px 2px rgba(0,0,0,.45), 0 16px 34px rgba(0,0,0,.55)', shadowSoft:'0 1px 3px rgba(0,0,0,.4)' },
  hearth:    { bg:'#181210', panel:'#241C18', surface:'#1F1814', dark:'#110C0A', ink:'#F4ECE3', ink2:'#B7A99C', ink3:'#7E7064', line:'#322821', lineSoft:'#261E19', stage:'#1A130F', shadow:'0 1px 2px rgba(0,0,0,.45), 0 12px 30px rgba(0,0,0,.5)', shadowSoft:'0 1px 3px rgba(0,0,0,.4)' },
};
const BLACK = {
  precision: { bg:'#000000', panel:'#0E1319', surface:'#080B10', dark:'#000000', ink:'#F1F6FB', ink2:'#A4AFBD', ink3:'#5F6975', line:'#1B2129', lineSoft:'#12161D', stage:'#000000', shadow:'0 1px 2px rgba(0,0,0,.6), 0 14px 34px rgba(0,0,0,.7)', shadowSoft:'0 1px 3px rgba(0,0,0,.6)' },
  signal:    { bg:'#000000', panel:'#100F1C', surface:'#0A0912', dark:'#000000', ink:'#F1F0FC', ink2:'#ABA9C2', ink3:'#67657F', line:'#201E32', lineSoft:'#15131F', stage:'#000000', shadow:'0 1px 2px rgba(0,0,0,.6), 0 16px 38px rgba(0,0,0,.7)', shadowSoft:'0 1px 3px rgba(0,0,0,.6)' },
  hearth:    { bg:'#000000', panel:'#150F12', surface:'#0C0809', dark:'#000000', ink:'#F7EFE9', ink2:'#BCAEA3', ink3:'#776A63', line:'#271D20', lineSoft:'#170F12', stage:'#000000', shadow:'0 1px 2px rgba(0,0,0,.6), 0 14px 34px rgba(0,0,0,.7)', shadowSoft:'0 1px 3px rgba(0,0,0,.6)' },
};

// ── ACCENT: independent colour axis. a = accent, d = deep (pressed/links), s = soft fill.
// Brighter on dark surfaces so CTAs stay legible. Excludes red/green by product rule. ──
const ACCENTS = {
  cobalt:    { name: 'Cobalt',    swatch: '#1B4FA0', light: { a: '#1B4FA0', d: '#143C7D', s: '#DEE9F6' }, dim: { a: '#3E73D8', d: '#A9C2EF', s: 'rgba(62,115,216,.20)' }, black: { a: '#3F78FF', d: '#A8C2FF', s: 'rgba(63,120,255,.18)' } },
  indigo:    { name: 'Indigo',    swatch: '#4733FF', light: { a: '#4733FF', d: '#3422DB', s: '#E6E2FF' }, dim: { a: '#7E6BFF', d: '#C7BCFF', s: 'rgba(126,107,255,.22)' }, black: { a: '#7A66FF', d: '#CFC4FF', s: 'rgba(122,102,255,.20)' } },
  plum:      { name: 'Plum',      swatch: '#7E3A6E', light: { a: '#7E3A6E', d: '#632C58', s: '#F1E4EE' }, dim: { a: '#C66FAC', d: '#EEBADD', s: 'rgba(198,111,172,.20)' }, black: { a: '#E96FBE', d: '#FFB6E1', s: 'rgba(233,111,190,.18)' } },
  turquoise: { name: 'Turquoise', swatch: '#0E8F8C', light: { a: '#0E8F8C', d: '#0B6F6D', s: '#D5EFEE' }, dim: { a: '#3FB8B5', d: '#A9E8E6', s: 'rgba(63,184,181,.20)' }, black: { a: '#2BD4CF', d: '#9DEFEC', s: 'rgba(43,212,207,.16)' } },
  fuchsia:   { name: 'Fuchsia',   swatch: '#D6398A', light: { a: '#D6398A', d: '#AC2C6E', s: '#FAE0EE' }, dim: { a: '#E86BAA', d: '#F6B9D7', s: 'rgba(232,107,170,.20)' }, black: { a: '#FF4D9E', d: '#FFB0D6', s: 'rgba(255,77,158,.16)' } },
  grape:     { name: 'Grape',     swatch: '#8139C2', light: { a: '#8139C2', d: '#66299E', s: '#EFE0F8' }, dim: { a: '#A86BE0', d: '#D9BCF5', s: 'rgba(168,107,224,.20)' }, black: { a: '#B14DFF', d: '#DDB8FF', s: 'rgba(177,77,255,.18)' } },
};
const ACCENT_ORDER = ['cobalt', 'indigo', 'plum', 'turquoise', 'fuchsia', 'grape'];

// ── FIXED safety palette resolved per mode (text flips light on dark) ──
const CATS = {
  light: {
    amber: '#E89318', unknownInk: '#8E857A',
    allergen:    { rail: '#D2870F', chipBg: '#FDEBC9', fg: '#96640F' },
    intolerance: { rail: '#CA6A2C', chipBg: '#FBE2CC', fg: '#A1531F' },
    goal:        { rail: '#6A7396', chipBg: '#E7E9F1', fg: '#4D5772' },
  },
  dark: {
    amber: '#F0A23A', unknownInk: '#9AA1AD',
    allergen:    { rail: '#E0A030', chipBg: 'rgba(224,160,48,.18)', fg: '#F0C079' },
    intolerance: { rail: '#DE8048', chipBg: 'rgba(222,128,72,.18)', fg: '#EDA777' },
    goal:        { rail: '#8C97B8', chipBg: 'rgba(140,151,184,.20)', fg: '#B6C0D6' },
  },
  black: {
    amber: '#FFB23D', unknownInk: '#8A93A2',
    allergen:    { rail: '#FFB23D', chipBg: 'rgba(255,178,61,.16)', fg: '#FFCE85' },
    intolerance: { rail: '#FF9352', chipBg: 'rgba(255,147,82,.16)', fg: '#FFB68A' },
    goal:        { rail: '#A6B2D6', chipBg: 'rgba(166,178,214,.18)', fg: '#C7D0E8' },
  },
};

// Resolve direction + accent + mode into one theme object the whole app reads from.
function buildS(dirKey, accentKey, mode) {
  if (mode === true) mode = 'dim';
  if (!mode || mode === false) mode = 'light';
  const mkey = mode === 'black' ? 'black' : mode === 'dim' ? 'dim' : 'light';
  const base = DIRS[dirKey] || DIRS.precision;
  const overlay = mode === 'black' ? BLACK[base.key] : mode === 'dim' ? DARK[base.key] : null;
  const merged = overlay ? { ...base, ...overlay } : { ...base };
  const cats = CATS[mode === 'black' ? 'black' : mode === 'dim' ? 'dark' : 'light'];
  const akey = ACCENTS[accentKey] ? accentKey : 'cobalt';
  const ac = ACCENTS[akey][mkey];
  const glow = mode === 'black' ? `0 0 0 1px ${ac.a}66, 0 8px 28px ${ac.a}99` : null;
  return { ...merged, ...cats, accent: ac.a, accentDeep: ac.d, accentSoft: ac.s, onAccent: '#FFFFFF', glow,
    dir: base.key, accentKey: akey, mode, isDark: mode !== 'light', isBlack: mode === 'black',
    childBg: '#E7D9C4', childFg: '#8A6B3D' };
}

if (typeof document !== 'undefined' && !document.getElementById('an3-css')) {
  const s = document.createElement('style');
  s.id = 'an3-css';
  s.textContent = `
    .an *{ box-sizing:border-box; }
    .an button{ font-family:inherit; cursor:pointer; border:none; background:none; padding:0; }
    .an-scroll{ overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch; }
    .an-scroll::-webkit-scrollbar{ width:0; display:none; }
    .an-scroll{ scrollbar-width:none; }
    .press{ transition:transform .12s ease, box-shadow .16s ease, background .16s ease, opacity .16s ease; }
    .press:active{ transform:scale(.975); }
    .tap{ transition:background .14s ease, border-color .14s ease, transform .1s ease; }
    .tap:active{ background:rgba(128,128,128,.06); }
    @keyframes an-up{ from{transform:translateY(10px); opacity:0;} to{transform:none; opacity:1;} }
    @keyframes an-sheet{ from{transform:translateY(34px);} to{transform:translateY(0);} }
    @keyframes an-pulse{ 0%,100%{opacity:.5;} 50%{opacity:1;} }
    @keyframes an-spin{ to{ transform:rotate(360deg);} }
    @keyframes an-scan{ 0%{top:10%;} 100%{top:72%;} }
    @keyframes an-vfade{ from{opacity:0; transform:translateY(8px);} to{opacity:1; transform:none;} }
    .vfade{ animation:an-vfade .34s ease both; }
  `;
  document.head.appendChild(s);
}

// ── icons — refreshed line set: rounded, friendly, a little more characterful ──
const I = {
  scan: (c, s = 26) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M4 8.5V6.8A2.8 2.8 0 0 1 6.8 4H8.5M15.5 4h1.7A2.8 2.8 0 0 1 20 6.8V8.5M20 15.5v1.7A2.8 2.8 0 0 1 17.2 20h-1.7M8.5 20H6.8A2.8 2.8 0 0 1 4 17.2v-1.7"/><path d="M7.5 12h9"/></svg>,
  back: (c, s = 20) => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11.5 5l-5 5 5 5M6.5 10h7"/></svg>,
  chev: (c, s = 18) => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3.5L11 9l-5 5.5"/></svg>,
  check: (c, s = 16) => <svg width={s} height={s} viewBox="0 0 16 16" fill="none" stroke={c} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 8.5l3.2 3.2L13 4.5"/></svg>,
  shield: (c, s = 17) => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M9 2.2l5.4 2.2v4.2c0 3.6-2.5 6.3-5.4 7.2-2.9-.9-5.4-3.6-5.4-7.2V4.4L9 2.2z"/><path d="M6.5 8.9l1.8 1.8 3.4-3.6"/></svg>,
  spark: (c, s = 18) => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9 2.2c.7 4 1.6 4.9 5.6 5.6-4 .7-4.9 1.6-5.6 5.6-.7-4-1.6-4.9-5.6-5.6 4-.7 4.9-1.6 5.6-5.6z"/></svg>,
  diary: (c, s = 21) => <svg width={s} height={s} viewBox="0 0 21 21" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M10.5 5.6C9.2 4.6 7.4 4.3 5.2 4.5c-.8.1-1.4.7-1.4 1.5v8.6c0 .5.4.9 1 .8 2-.2 3.6.1 5.7 1.1"/><path d="M10.5 5.6c1.3-1 3.1-1.3 5.3-1.1.8.1 1.4.7 1.4 1.5v8.6c0 .5-.4.9-1 .8-2-.2-3.6.1-5.7 1.1"/><path d="M10.5 5.6v11.4"/></svg>,
  pulse: (c, s = 21) => <svg width={s} height={s} viewBox="0 0 21 21" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3.5 14.5l4-5 3 3 5.5-6.5"/><circle cx="16" cy="6" r="1.5" fill={c} stroke="none"/></svg>,
  user: (c, s = 21) => <svg width={s} height={s} viewBox="0 0 21 21" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="10.5" cy="7.4" r="3.3"/><path d="M4.6 17.2c.8-3.2 3-4.8 5.9-4.8s5.1 1.6 5.9 4.8"/></svg>,
  edit: (c, s = 12) => <svg width={s} height={s} viewBox="0 0 12 12" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M8.5 1.5l2 2-6 6-2.5.5.5-2.5 6-6z"/></svg>,
  plus: (c, s = 16) => <svg width={s} height={s} viewBox="0 0 16 16" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round"><path d="M8 3v10M3 8h10"/></svg>,
  x: (c, s = 18) => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round"><path d="M4 4l10 10M14 4L4 14"/></svg>,
  flash: (c, s = 18) => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2v2.5M10 15.5V18M3.6 5.2l1.8 1.8M14.6 13.2l1.8 1.8M2 10h2.5M15.5 10H18M3.6 14.8l1.8-1.8M14.6 6.8l1.8-1.8"/><circle cx="10" cy="10" r="2.7"/></svg>,
  palette: (c, s = 18) => <svg width={s} height={s} viewBox="0 0 20 20" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2.5a7.5 7.5 0 0 0 0 15c1.2 0 1.8-1 1.4-2-.4-1 .2-2 1.3-2H15a3 3 0 0 0 3-3c0-4.1-3.6-6-8-6z"/><circle cx="6.6" cy="9.2" r=".7" fill={c} stroke="none"/><circle cx="9.6" cy="6.4" r=".7" fill={c} stroke="none"/><circle cx="13" cy="8" r=".7" fill={c} stroke="none"/></svg>,
  info: (c, s = 14) => <svg width={s} height={s} viewBox="0 0 18 18" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="9" r="7"/><path d="M9 8.2v4"/><circle cx="9" cy="5.6" r=".7" fill={c} stroke="none"/></svg>,
};

// ── atoms ──
function Status({ S, dark }) {
  const c = dark ? 'rgba(255,255,255,.92)' : S.ink;
  return (
    <div style={{ height: 46, flex: '0 0 46px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', color: c, fontFamily: S.body }}>
      <span style={{ fontWeight: 700, fontSize: 14.5, fontVariantNumeric: 'tabular-nums' }}>9:41</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11" fill={c}><rect x="0" y="6" width="3" height="5" rx="1"/><rect x="4.5" y="4" width="3" height="7" rx="1"/><rect x="9" y="2" width="3" height="9" rx="1"/><rect x="13.5" y="0" width="3" height="11" rx="1"/></svg>
        <svg width="22" height="11" viewBox="0 0 22 11" fill="none"><rect x="1" y="1" width="18" height="9" rx="2.5" stroke={c} strokeOpacity=".45"/><rect x="3" y="3" width="13" height="5" rx="1" fill={c}/></svg>
      </div>
    </div>
  );
}

function Btn({ S, children, onClick, variant = 'primary', style = {}, size = 'lg' }) {
  const h = size === 'lg' ? 54 : 46;
  const looks = {
    primary: { background: S.accent, color: S.onAccent, boxShadow: S.glow || `0 6px 16px ${S.accent}30` },
    soft: { background: S.accentSoft, color: S.accentDeep },
    ghost: { background: 'transparent', color: S.ink2 },
    outline: { background: S.surface, color: S.ink, boxShadow: `inset 0 0 0 1.5px ${S.line}` },
    light: { background: 'rgba(255,255,255,.16)', color: '#fff' },
  }[variant];
  return (
    <button className="press" onClick={onClick} style={{ height: h, minHeight: 44, borderRadius: S.btnR, width: '100%',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontFamily: S.body, fontWeight: 700,
      fontSize: size === 'lg' ? 16 : 15, letterSpacing: '.1px', ...looks, ...style }}>{children}</button>
  );
}

function Logo({ S, light, size = 19 }) {
  const r = S.dir === 'signal' ? 13 : S.dir === 'precision' ? 9 : 11;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{ width: 38, height: 38, borderRadius: r, background: S.accent, display: 'grid', placeItems: 'center', boxShadow: S.glow || `0 5px 14px ${S.accent}38` }}>{I.scan(S.onAccent, 20)}</div>
      <span style={{ fontFamily: S.head, fontWeight: S.headWt, fontSize: size, letterSpacing: S.headLs, color: light ? '#fff' : S.ink }}>Anvara</span>
    </div>
  );
}

function AmberDot({ S, s = 13, ring }) {
  return <span style={{ width: s, height: s, borderRadius: '50%', background: (S ? S.amber : '#E89318'), flex: `0 0 ${s}px`, display: 'inline-block', boxShadow: ring ? `0 0 0 ${s * .28}px ${(S ? S.amber : '#E89318')}26` : 'none' }} />;
}

function Avatar({ S, name, child, size = 16 }) {
  return (
    <span style={{ width: size, height: size, borderRadius: child ? size * 0.32 : '50%', display: 'grid', placeItems: 'center', flex: `0 0 ${size}px`,
      fontSize: size * 0.5, fontWeight: 800, fontFamily: S.body, background: child ? S.childBg : S.accentSoft, color: child ? S.childFg : S.accentDeep }}>{name[0]}</span>
  );
}

function SessionChip({ S, name, child }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, height: 24, padding: '0 10px 0 5px', borderRadius: 999, background: S.panel, fontFamily: S.body, fontWeight: 700, fontSize: 12, color: S.ink2 }}>
      <Avatar S={S} name={name} child={child} />{name}
    </span>
  );
}

function Overline({ S, children, color }) {
  return <div style={{ fontFamily: S.mono, fontSize: 10.5, letterSpacing: '1.4px', textTransform: 'uppercase', color: color || S.ink3, fontWeight: 500 }}>{children}</div>;
}

function Card({ S, children, style = {}, onClick, className }) {
  const look = S.card === 'border'
    ? { background: S.surface, boxShadow: `inset 0 0 0 1px ${S.line}`, borderRadius: S.radius }
    : S.card === 'soft'
      ? { background: S.surface, boxShadow: S.shadowSoft, borderRadius: S.radius }
      : { background: S.surface, boxShadow: S.shadow, borderRadius: S.radius };
  const Tag = onClick ? 'button' : 'div';
  return <Tag onClick={onClick} className={className} style={{ display: 'block', textAlign: 'left', width: onClick ? '100%' : undefined, ...look, ...style }}>{children}</Tag>;
}

function Slot({ S, label, style = {}, r }) {
  return (
    <div style={{ position: 'relative', overflow: 'hidden', borderRadius: r != null ? r : S.radius,
      background: `repeating-linear-gradient(135deg, ${S.panel}, ${S.panel} 7px, ${S.lineSoft} 7px, ${S.lineSoft} 14px)`,
      display: 'grid', placeItems: 'center', boxShadow: `inset 0 0 0 1px ${S.line}`, ...style }}>
      <span style={{ fontFamily: S.mono, fontSize: 9.5, letterSpacing: '1px', textTransform: 'uppercase', color: S.ink3, background: S.surface, padding: '3px 7px', borderRadius: 5 }}>{label}</span>
    </div>
  );
}

// Gentle, non-alarming disclaimer line. Small info glyph + muted text. Reassuring, brief.
function SafetyNote({ S, children, style = {}, center, top }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: center ? 'center' : 'flex-start', gap: 6,
      paddingTop: top ? 11 : 0, borderTop: top ? `1px solid ${S.lineSoft}` : 'none', ...style }}>
      <span style={{ marginTop: 1, flex: '0 0 auto', opacity: .85 }}>{I.info(S.ink3, 13)}</span>
      <span style={{ fontFamily: S.body, fontSize: 11.5, lineHeight: 1.5, color: S.ink3, maxWidth: 300, textAlign: center ? 'center' : 'left' }}>{children}</span>
    </div>
  );
}

function TabBar({ S, active, onChange }) {
  const items = [['scan', 'Scan', I.scan], ['diary', 'Diary', I.diary], ['patterns', 'Patterns', I.pulse], ['profile', 'Profile', I.user]];
  return (
    <div style={{ flex: '0 0 auto', display: 'flex', background: S.surface, borderTop: `1px solid ${S.line}`, padding: '8px 6px 22px' }}>
      {items.map(([key, label, icon]) => {
        const on = active === key; const c = on ? S.accent : S.ink3;
        return (
          <button key={key} className="press" onClick={() => onChange(key)} style={{ flex: 1, minHeight: 44, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '4px 0' }}>
            {icon(c, 21)}
            <span style={{ fontFamily: S.body, fontSize: 10.5, fontWeight: on ? 800 : 600, color: c }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

function PhoneStage({ S, children }) {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => setScale(Math.min(1, (window.innerHeight - 28) / 844, (window.innerWidth - 28) / 390));
    fit(); window.addEventListener('resize', fit); return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: S.stage, overflow: 'hidden' }}>
      <div style={{ transform: `scale(${scale})`, transformOrigin: 'center' }}>
        <div style={{ width: 390, height: 844, borderRadius: 46, background: S.bg, overflow: 'hidden', position: 'relative',
          boxShadow: '0 2px 4px rgba(20,20,30,.08), 0 30px 80px rgba(20,20,30,.22), 0 0 0 1px rgba(20,20,30,.05)' }}>
          {children}
          <div style={{ position: 'absolute', left: '50%', bottom: 9, transform: 'translateX(-50%)', width: 128, height: 5, borderRadius: 3, background: 'rgba(120,120,130,.3)', zIndex: 60, pointerEvents: 'none' }} />
        </div>
      </div>
    </div>
  );
}

function Screen({ S, children, dark, scroll = true, bg, bodyRef }) {
  return (
    <div className="an" style={{ width: 390, height: 844, background: bg || S.bg, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <Status S={S} dark={dark} />
      <div ref={bodyRef} className={scroll ? 'an-scroll' : ''} style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>{children}</div>
    </div>
  );
}

Object.assign(window, { DIRS, DARK, BLACK, ACCENTS, ACCENT_ORDER, CATS, buildS, I, Status, Btn, Logo, AmberDot, Avatar, SessionChip, Overline, Card, Slot, SafetyNote, TabBar, PhoneStage, Screen });
